import * as T from './three.module.js';
const $=i=>document.getElementById(i),RN=(a,b)=>a+Math.random()*(b-a),RI=(a,b)=>Math.floor(RN(a,b+1)),pick=a=>a[RI(0,a.length-1)];
const ren=new T.WebGLRenderer({antialias:false});ren.setPixelRatio(Math.min(devicePixelRatio,1.5));ren.setSize(innerWidth,innerHeight);document.body.prepend(ren.domElement);
const cam=new T.PerspectiveCamera(75,innerWidth/innerHeight,.1,100);
addEventListener('resize',()=>{ren.setSize(innerWidth,innerHeight);cam.aspect=innerWidth/innerHeight;cam.updateProjectionMatrix()});
const MAT={},mat=c=>MAT[c]||(MAT[c]=new T.MeshLambertMaterial({color:c})),bas=(c,o={})=>new T.MeshBasicMaterial(Object.assign({color:c},o));
let scene,boxes,ents,clouds,fxs,mode='',P,M,paused=0,over=0,yaw=0,pitch=0,items,furn,creaks,evs,nodes,waves=0,msgT=0,hudT=0,SP,again=()=>{},nH=1;
const inp={mx:0,mz:0,fire:0,run:0,jump:0},adm={};
const gunM=new T.Mesh(new T.BoxGeometry(.12,.14,.6),mat(0x222222));gunM.position.set(.3,-.28,-.6);
let AC;const beep=(f,d,tp='square',v=.04)=>{try{AC=AC||new AudioContext();const o=AC.createOscillator(),g=AC.createGain();o.type=tp;o.frequency.value=f;g.gain.value=v;o.connect(g);g.connect(AC.destination);o.start();o.stop(AC.currentTime+d)}catch(e){}};
const say=t=>{$('msg').textContent=t;msgT=3};
const flash=()=>{const f=$('fl');f.style.opacity=.6;setTimeout(()=>f.style.opacity=0,150)};

// ---------- ЛОГИКА БОЯ / УЛУЧШЕНИЯ ----------
const base=()=>({mag:3,dmg:25,rate:.45,reload:1.6,speed:6.2,hp:100,jump:8,poison:0,freeze:0,shock:0,vamp:0,crit:0,regen:0,expl:0});
const UP=[
['+2 патрона',s=>s.mag+=2],['+урон (+10)',s=>s.dmg+=10],['+скорострельность',s=>s.rate*=.75],
['−1 патрон, +20 урона',s=>{s.mag=Math.max(1,s.mag-1);s.dmg+=20}],['−скорострельность, +25 урона',s=>{s.rate*=1.5;s.dmg+=25}],
['☠ Ядовитый дым после выстрела',s=>s.poison++],['❄ Заморозка (замедляет)',s=>s.freeze++],['⚡ Молния бьёт по ближайшему',s=>s.shock++],
['🩸 Вампиризм 20%',s=>s.vamp+=.2],['🎯 Крит 25% (x2)',s=>s.crit+=.25],['+30 здоровья',s=>s.hp+=30],['Быстрая перезарядка',s=>s.reload*=.6],
['Скорость +20%',s=>s.speed*=1.2],['Регенерация +3 HP/с',s=>s.regen+=3],['💣 Взрывные пули',s=>s.expl++],['Высокий прыжок',s=>s.jump*=1.3],
['Стекл. пушка: урон x2, −40 HP',s=>{s.dmg*=2;s.hp=Math.max(30,s.hp-40)}],['−3 патрона... но +2 урона/пулю ×3 (дробь)',s=>{s.dmg+=15;s.rate*=.9}]];
function box(x0,y0,z0,x1,y1,z1,c,s=1){boxes.push({x0,y0,z0,x1,y1,z1,s});const m=new T.Mesh(new T.BoxGeometry(x1-x0,y1-y0,z1-z0),mat(c));m.position.set((x0+x1)/2,(y0+y1)/2,(z0+z1)/2);scene.add(m)}
function wall(x1,z1,x2,z2,y0,h,gaps=[],c=0x8a8f98,t=.15){const xa=x1!=x2,lo=xa?x1:z1,hi=xa?x2:z2;let cur=lo;const sg=[];for(const g of gaps.slice().sort((p,q)=>p[0]-q[0])){sg.push([cur,g[0]]);cur=g[1]}sg.push([cur,hi]);for(const[a,b]of sg){if(b-a<.01)continue;xa?box(a,y0,z1-t,b,y0+h,z1+t,c):box(x1-t,y0,a,x1+t,y0+h,b,c)}}
function slab(y0,y1,hx0,hz0,hx1,hz1,c){box(0,y0,0,24,y1,hz0,c,0);box(0,y0,hz1,24,y1,20,c,0);box(0,y0,hz0,hx0,y1,hz1,c,0);box(hx1,y0,hz0,24,y1,hz1,c,0)}
function stairs(x,z,dir,w,n){for(let i=0;i<n;i++){const h=.4*(i+1),s=dir%2?-1:1;if(dir<2){const a=x+s*i,b=x+s*(i+1);box(Math.min(a,b),0,z,Math.max(a,b),h,z+w,0x777788,0)}else{const a=z+s*i,b=z+s*(i+1);box(x,0,Math.min(a,b),x+w,h,Math.max(a,b),0x777788,0)}}}
const RAD=.3;
const blocked=(x,z,y,h)=>{for(const b of boxes)if(x+RAD>b.x0&&x-RAD<b.x1&&z+RAD>b.z0&&z-RAD<b.z1&&y+h>b.y0&&y+.55<b.y1)return 1;return 0};
const ground=(x,z,y)=>{let g=-99;for(const b of boxes)if(x>b.x0-.2&&x<b.x1+.2&&z>b.z0-.2&&z<b.z1+.2&&b.y1<=y+.6&&b.y1>g)g=b.y1;return g};
function phys(e,vx,vz,dt){const h=e.cr?1.1:1.8;let nx=e.x+vx*dt;if(!blocked(nx,e.z,e.y,h))e.x=nx;let nz=e.z+vz*dt;if(!blocked(e.x,nz,e.y,h))e.z=nz;
 if(e.fly){e.y+=e.fy*dt;e.vy=0;return}
 e.vy-=24*dt;const ny=e.y+e.vy*dt,g=ground(e.x,e.z,e.y);if(ny<=g){e.y=g;e.vy=0;e.gr=1}else{e.y=ny;e.gr=0}}
function ray(o,d,R,sh){let x,y,z;for(let t=.3;t<=R;t+=.25){x=o.x+d.x*t;y=o.y+d.y*t;z=o.z+d.z*t;
 for(const b of boxes)if(x>b.x0&&x<b.x1&&y>b.y0&&y<b.y1&&z>b.z0&&z<b.z1)return{x,y,z};
 for(const e of ents)if(e!==sh&&e.alive&&!e.hid){const dx=e.x-x,dz=e.z-z;if(dx*dx+dz*dz<.25&&y>e.y&&y<e.y+(e.cr?1.2:1.9))return{x,y,z,e}}}return{x,y,z}}
function line(a,b,c){const g=new T.BufferGeometry().setFromPoints([new T.Vector3(a.x,a.y,a.z),new T.Vector3(b.x,b.y,b.z)]);const l=new T.Line(g,new T.LineBasicMaterial({color:c}));scene.add(l);fxs.push({m:l,t:.08})}
const angDir=(y,p)=>({x:-Math.sin(y)*Math.cos(p),y:Math.sin(p),z:-Math.cos(y)*Math.cos(p)});
function mk(o){const g=new T.Group(),b=new T.Mesh(new T.BoxGeometry(.7,1.1,.4),mat(o.c||0x884444));b.position.y=.75;const h=new T.Mesh(new T.BoxGeometry(.42,.42,.42),mat(0xe0b890));h.position.y=1.55;g.add(b,h);
 const xr=new T.Mesh(new T.BoxGeometry(.9,1.9,.7),bas(0xff2222,{transparent:true,opacity:.35,depthTest:false}));xr.position.y=.95;xr.renderOrder=9;xr.visible=false;g.add(xr);scene.add(g);
 return Object.assign({g,xr,x:0,y:0,z:0,vy:0,yaw:0,hp:100,maxhp:100,alive:1,slow:0,cd:0,rl:0,k:0,s:base(),mag:3,cr:0,gr:0,rt:0,think:0,tg:null,los:0,lives:3,inv:0,hid:null,hidT:0,sd:1,sk:.6,wt:0,lx:0,lz:0},o)}
function respawn(e,i){let best=0,bd=-1;if(i==null){SP.forEach((s,j)=>{let m=1e9;for(const o of ents)if(o!==e&&o.alive)m=Math.min(m,Math.hypot(o.x-s[0],o.z-s[1]));if(m>bd){bd=m;best=j}});i=best}
 const s=SP[i];e.x=s[0];e.z=s[1];e.y=ground(s[0],s[1],30);e.vy=0;e.maxhp=e.s.hp;e.hp=e.maxhp;e.mag=e.s.mag;e.rl=0;e.alive=1;e.slow=0;e.pending=0;e.cd=.5;
 if(e.isP)yaw=Math.atan2(-(30-e.x),-(30-e.z)),pitch=0}
function hurt(e,d,by){if(e.isP&&adm.god)return;if(!e.alive)return;e.hp-=d;if(e.isP)flash();if(e.hp<=0)die(e,by)}
function die(e,by){e.alive=0;e.rt=2.5;if(by&&by!==e)by.k++;
 if(e.isP){e.pending=1;showUp()}else pick(UP)[1](e.s);
 if(mode=='pistol'&&by&&by.k>=10){over=1;$('end').innerHTML=`<h2>${by.isP?'🏆 Вы победили!':'Победил '+by.name}</h2>`;endBtns()}}
function showUp(){const pool=UP.slice().sort(()=>Math.random()-.5).slice(0,5),el=$('up');el.innerHTML='<h3>Вы погибли — выберите улучшение</h3>';
 pool.forEach(u=>{const b=document.createElement('button');b.textContent=u[0];b.onclick=()=>{u[1](P.s);P.pending=0;P.rt=1;el.classList.add('h')};el.appendChild(b)});el.classList.remove('h')}
function hit(by,e,r){let d=by.s.dmg*(Math.random()<by.s.crit?2:1)*(by.isP&&adm.one?10:1);hurt(e,d,by);
 if(by.s.vamp)by.hp=Math.min(by.maxhp,by.hp+d*by.s.vamp);
 if(by.s.freeze)e.slow=2.5;
 if(by.s.poison)cloud(r,by);
 if(by.s.shock){let n=null,nd=9;for(const o of ents)if(o!==by&&o!==e&&o.alive){const q=Math.hypot(o.x-e.x,o.z-e.z);if(q<nd){nd=q;n=o}}if(n){line({x:e.x,y:e.y+1.2,z:e.z},{x:n.x,y:n.y+1.2,z:n.z},0x66ccff);hurt(n,d*.4,by)}}
 if(by.s.expl){for(const o of ents)if(o!==by&&o!==e&&o.alive&&Math.hypot(o.x-r.x,o.z-r.z)<3)hurt(o,d*.5,by)}}
function cloud(r,by){const m=new T.Mesh(new T.SphereGeometry(2,8,6),bas(0x44ff44,{transparent:true,opacity:.3}));m.position.set(r.x,r.y,r.z);scene.add(m);clouds.push({m,x:r.x,y:r.y,z:r.z,t:4,by})}
function shoot(e){if(e.cd>0||e.rl>0||!e.alive)return;if(e.mag<=0){e.rl=e.s.reload;return}
 e.cd=e.s.rate;if(!(e.isP&&adm.inf))e.mag--;const o={x:e.x,y:e.y+(e.cr?1:1.55),z:e.z},d=e.aim,r=ray(o,d,70,e);
 line({x:o.x,y:o.y-.15,z:o.z},r,e.isP?0xffee66:0xff6655);if(e.isP){beep(180,.07,'sawtooth');gunM.position.z=-.5}
 if(r.e)hit(e,r.e,r);if(e.mag<=0&&!e.isP)e.rl=e.s.reload}

// ---------- УПРАВЛЕНИЕ ИГРОКА ----------
function ctl(dt){const e=P;const f=inp.mz,r=inp.mx;e.mv=Math.hypot(f,r)>.15&&!e.hid;e.yaw=yaw;if(e.hid)return;
 let sp=mode=='horror'?(e.cr?1.7:inp.run?6.2:3.6):(e.cr?3:inp.run?e.s.speed*1.45:e.s.speed);
 sp*=(adm.speed?2.6:1)*(e.slow>0?.5:1);e.run=inp.run&&!e.cr;e.fly=!!adm.fly;e.fy=e.fly?((inp.jump?10:0)-(e.cr?10:0)):0;
 if(e.fly)sp=Math.max(sp,10);
 if(inp.jump&&e.gr&&!e.fly)e.vy=e.s.jump;
 phys(e,(-Math.sin(yaw)*f+Math.cos(yaw)*r)*sp,(-Math.cos(yaw)*f-Math.sin(yaw)*r)*sp,dt);
 if(inp.fire){if(mode=='horror')shootH();else{e.aim=angDir(yaw,pitch);shoot(e)}}}
function act(a){if(!P||over)return;
 if(a=='reload'&&mode!='horror'&&P.rl<=0&&P.mag<P.s.mag)P.rl=P.s.reload;
 if(a=='use'&&mode=='horror')use();
 if(a=='crouch'){P.cr=P.cr?0:1;$('b_crouch').style.background=P.cr?'#2b6':''}
 if(a=='run'){inp.run=inp.run?0:1;$('b_run').style.background=inp.run?'#2b6':''}}

// ---------- БОТЫ (АРЕНА) ----------
function bot(b,dt){b.think-=dt;
 if(b.think<=0){b.think=.3;let tg=null,bd=1e9;for(const e of ents){if(e===b||!e.alive||(e.isP&&adm.invis))continue;const d=Math.hypot(e.x-b.x,e.z-b.z)+Math.abs(e.y-b.y);if(d<bd){bd=d;tg=e}}
  b.tg=tg;b.los=0;if(tg){const o={x:b.x,y:b.y+1.5,z:b.z},dx=tg.x-o.x,dy=tg.y+1.2-o.y,dz=tg.z-o.z,l=Math.hypot(dx,dy,dz)||1;if(l<45){const r=ray(o,{x:dx/l,y:dy/l,z:dz/l},l+1,b);b.los=r.e===tg}}
  if(Math.random()<.3)b.sd=-b.sd}
 b.sk-=dt;if(b.sk<=0){b.sk=.6;if(b.mv&&Math.hypot(b.x-b.lx,b.z-b.lz)<.5){b.wy=RN(0,6.28);b.wt=1.2;if(b.gr)b.vy=b.s.jump}b.lx=b.x;b.lz=b.z}
 let vx=0,vz=0;const sp=b.s.speed*(b.slow>0?.5:1)*.9;b.mv=0;
 if(b.tg){const dx=b.tg.x-b.x,dz=b.tg.z-b.z,d=Math.hypot(dx,dz)||1;b.yaw=Math.atan2(-dx,-dz);let ux=dx/d,uz=dz/d,fw=1,st=0;
  if(b.wt>0){b.wt-=dt;ux=-Math.sin(b.wy);uz=-Math.cos(b.wy)}else if(b.los){fw=d>12?1:d<5?-.6:0;st=b.sd}
  vx=(ux*fw-uz*st)*sp;vz=(uz*fw+ux*st)*sp;b.mv=Math.abs(fw)+Math.abs(st)>0;
  if(!b.los&&b.gr&&Math.random()<dt*.4)b.vy=b.s.jump;
  if(b.los&&d<42&&b.cd<=0&&b.rl<=0){const er=.05*d,o={x:b.x,y:b.y+1.5,z:b.z},ax=dx+RN(-er,er),ay=b.tg.y+1.2-o.y+RN(-er,er),az=dz+RN(-er,er),l=Math.hypot(ax,ay,az);b.aim={x:ax/l,y:ay/l,z:az/l};shoot(b)}}
 if(b.mag<=0&&b.rl<=0)b.rl=b.s.reload;
 phys(b,vx,vz,dt)}
function aUpdate(dt){for(const e of ents){
 if(!e.alive){if(!e.pending){e.rt-=dt;if(e.rt<=0)respawn(e)}continue}
 e.cd-=dt;if(e.rl>0){e.rl-=dt;if(e.rl<=0)e.mag=e.s.mag}e.slow-=dt;e.hp=Math.min(e.maxhp,e.hp+e.s.regen*dt);
 if(e.isP)ctl(dt);else bot(e,dt);if(e.y<-20)respawn(e)}
 for(let i=clouds.length-1;i>=0;i--){const c=clouds[i];c.t-=dt;for(const e of ents)if(e!==c.by&&e.alive&&Math.hypot(e.x-c.x,e.z-c.z)<2.3&&Math.abs(e.y+1-c.y)<3)hurt(e,14*dt,c.by);if(c.t<=0){scene.remove(c.m);clouds.splice(i,1)}}}
function arena(k){box(-5,-2,-5,65,0,65,0x4a6b3a,0);[[0,0,60,0],[0,60,60,60],[0,0,0,60],[60,0,60,60]].forEach(a=>wall(a[0],a[1],a[2],a[3],0,8,[],0x555a66,.5));
 let s=7;const rnd=()=>(s=(s*16807)%2147483647)/2147483647;
 if(k==0){for(let i=0;i<26;i++){const w=2+rnd()*3,d=2+rnd()*3,h=[1.2,2.4,3.6][Math.floor(rnd()*3)],x=8+rnd()*(44-w),z=8+rnd()*(44-d);if((x<14||x>46)&&(z<14||z>46))continue;box(x,0,z,x+w,h,z+d,0x9b7b4a)}}
 if(k==1){box(20,0,20,40,3.2,40,0x8a8a99);stairs(12,28.5,0,3,8);stairs(48,28.5,1,3,8);stairs(28.5,12,2,3,8);stairs(28.5,48,3,3,8);box(26,3.2,26,28,4.6,34,0x666677);box(32,3.2,26,34,4.6,34,0x666677);[[10,10],[48,10],[10,48],[48,48]].forEach(p=>box(p[0],0,p[1],p[0]+2,5,p[1]+2,0x776655))}
 if(k==2){[[14,14,46,14,[[26,32]]],[14,46,46,46,[[28,34]]],[14,14,14,46,[[24,30]]],[46,14,46,46,[[20,26]]],[24,24,36,24,[[28,32]]],[24,36,36,36,[[28,32]]],[24,24,24,36,[]],[36,24,36,36,[[28,32]]],[30,0,30,14,[]],[30,46,30,60,[]]].forEach(a=>wall(a[0],a[1],a[2],a[3],0,4,a[4],0x8a7a6a,.3));box(8,0,24,11,1.2,28,0x9b7b4a);box(49,0,32,52,1.2,36,0x9b7b4a)}
 if(k==3){box(0,0,20,18,1.6,40,0x7a7a66);stairs(22,28,1,4,4);box(42,0,20,60,3.2,40,0x7a7a88);stairs(34,28,0,4,8);box(28,0,10,32,3,22,0x665544);box(28,0,38,32,3,50,0x665544);box(26,0,28,34,1.2,32,0x9b7b4a)}}
function startArena(k,sb){init();mode=sb?'sand':'pistol';arena(k);scene.add(new T.HemisphereLight(0xffffff,0x445566,1.2));const d=new T.DirectionalLight(0xffffff,.8);d.position.set(30,50,20);scene.add(d);scene.background=new T.Color(0x9ec5e8);
 SP=[[6,6],[54,6],[6,54],[54,54]];P=mk({isP:1,c:0x2255cc,name:'Вы'});ents=[P];for(let i=0;i<3;i++)ents.push(mk({isB:1,c:[0xcc3333,0x33aa33,0xccaa22][i],name:'Бот '+(i+1)}));ents.forEach((e,i)=>respawn(e,i));
 $('b_ham').style.display=sb?'flex':'none';$('b_use').style.display='none';gunM.visible=true;again=()=>startArena(k,sb);hud()}

// ---------- ХОРРОР ----------
const NODES=[[12,18.5,0],[6,15,0],[12,14,0],[18,15,0],[2,10.6,0],[4.2,19.6,0],[6,10,0],[18,10,0],[6,5,0],[12,5,0],[18,5,0],[2,19.5,3.2],[5,15,3.2],[8,15,3.2],[12,15,3.2],[16,15,3.2],[20,15,3.2],[6,10,3.2],[12,10,3.2],[18,10,3.2],[4,5,3.2],[8,5,3.2],[12,5,3.2],[16,5,3.2],[20,5,3.2],[4.2,10.5,-3.2],[4,4,-3.2],[4,16,-3.2],[8,10,-3.2],[12,10,-3.2],[12,4,-3.2],[12,16,-3.2],[16,10,-3.2],[20,10,-3.2],[20,4,-3.2],[20,16,-3.2]];
const FUR=[['c',1.2,1.5,0],['t',6,4,0],['t',18,7,0],['b',21,3,0],['c',22.5,8,0],['t',14,15,0],['c',22,18,0],['b',4,3,3.2],['b',12,3,3.2],['b',20,3,3.2],['c',1.2,8,3.2],['c',14.5,8,3.2],['c',22.5,8,3.2],['t',12,16,3.2],['t',20,16,3.2],['c',10,19,3.2],['t',4,3,-3.2],['c',11,18,-3.2],['t',20,14,-3.2],['c',23,2,-3.2],['t',12,6,-3.2]];
const ISP=[[3,3,0],[22,3,0],[6,17,0],[22,17,0],[3,17,3.2],[12,3,3.2],[22,3,3.2],[22,17,3.2],[12,17,3.2],[3,3,-3.2],[12,3,-3.2],[22,17,-3.2],[3,17,-3.2],[12,8,-3.2],[16,8,0]];
const CRK=[[6,13,0],[18,13,0],[6,3,0],[18,3,0],[4,13,3.2],[12,13,3.2],[20,13,3.2],[4,3,3.2],[12,3,3.2],[20,3,3.2],[12,8,0],[12,8,3.2]];
function lclear(x1,z1,x2,z2,y,h=1.2){const d=Math.hypot(x2-x1,z2-z1),n=Math.ceil(d/.35);for(let i=0;i<=n;i++){const x=x1+(x2-x1)*i/n,z=z1+(z2-z1)*i/n;for(const b of boxes)if(b.s&&x>b.x0&&x<b.x1&&z>b.z0&&z<b.z1&&y+h>b.y0&&y+h<b.y1)return 0}return 1}
function house(){const W=24,D=20,H=3.2,c1=0x7a6a5a;box(0,-3.5,0,W,-3.2,D,0x333333,0);slab(-.3,0,3.2,11,5.3,19,0x4a3a2a);slab(2.9,3.2,.9,11,3.1,19,0x5a4a3a);box(0,6.4,0,W,6.7,D,0x222222,0);
 for(const y of[-3.2,0,3.2])[[0,0,W,0],[0,D,W,D],[0,0,0,D],[W,0,W,D]].forEach(a=>wall(a[0],a[1],a[2],a[3],y,H,[],0x6b5b4b));
 wall(0,10,W,10,0,H,[[5,7],[17,19]],c1);wall(12,0,12,10,0,H,[[4,6]],c1);
 wall(0,10,W,10,3.2,H,[[5,7],[11,13],[17,19]],c1);wall(8,0,8,D,3.2,H,[[4,6],[14,16]],c1);wall(16,0,16,D,3.2,H,[[4,6],[14,16]],c1);
 wall(8,0,8,D,-3.2,H,[[9,11],[15,17]],c1);wall(16,0,16,D,-3.2,H,[[9,11],[15,17]],c1);
 for(let i=0;i<8;i++)box(1,0,11+i,3,.4*(i+1),12+i,0x6e4b2a,0);for(let i=0;i<7;i++)box(3.5,-3.2,18-i,5,-.4*(i+1),19-i,0x5a4a3a,0);
 box(11,0,19.7,13,2.6,20.3,0x5a2d12);
 FUR.forEach(([k,x,z,y])=>{furn.push({k,x,z,y});if(k=='c')box(x-.45,y,z-.3,x+.45,y+2,z+.3,0x6a3d1c);else if(k=='t')box(x-.7,y+.65,z-.4,x+.7,y+.75,z+.4,0x8a5a2a,0);else box(x-.5,y,z-.9,x+.5,y+.5,z+.9,0x8844aa,0)});
 nodes=NODES.map(n=>({x:n[0],z:n[1],y:n[2],adj:[]}));
 for(let i=0;i<nodes.length;i++)for(let j=i+1;j<nodes.length;j++){const a=nodes[i],b=nodes[j];if(Math.abs(a.y-b.y)<1&&Math.hypot(a.x-b.x,a.z-b.z)<13&&lclear(a.x,a.z,b.x,b.z,a.y)){a.adj.push(j);b.adj.push(i)}}
 [[4,11],[5,25]].forEach(([a,b])=>{nodes[a].adj.push(b);nodes[b].adj.push(a)})}
function near(p){let bi=-1,bd=1e9,fb=-1,fd=1e9;nodes.forEach((n,i)=>{if(Math.abs(n.y-p.y)>2)return;const d=Math.hypot(n.x-p.x,n.z-p.z);if(d<fd){fd=d;fb=i}if(d<bd&&lclear(p.x,p.z,n.x,n.z,p.y)){bd=d;bi=i}});return bi>=0?bi:fb}
function route(e,d){const a=near(e),b=near(d),fin={x:d.x,y:d.y,z:d.z};if(a<0||b<0)return[fin];const dist=nodes.map(()=>1e9),prev=nodes.map(()=>-1),done=[];dist[a]=0;
 for(;;){let u=-1;for(let i=0;i<nodes.length;i++)if(!done[i]&&(u<0||dist[i]<dist[u]))u=i;if(u<0||dist[u]>=1e9)break;done[u]=1;if(u==b)break;
  for(const v of nodes[u].adj){const w=dist[u]+Math.hypot(nodes[u].x-nodes[v].x,nodes[u].z-nodes[v].z)+Math.abs(nodes[u].y-nodes[v].y)*3;if(w<dist[v]){dist[v]=w;prev[v]=u}}}
 const r=[];for(let c=b;c>=0;c=prev[c])r.unshift({x:nodes[c].x,y:nodes[c].y,z:nodes[c].z});r.push(fin);return r}
function navStep(e,d,sp,dt){e.pt=(e.pt||0)-dt;if(!e.path||e.pt<=0||!e.pd||Math.hypot(e.pd.x-d.x,e.pd.z-d.z)>1.5||Math.abs(e.pd.y-d.y)>1.5){e.path=route(e,d);e.pd={x:d.x,y:d.y,z:d.z};e.pt=1.2}
 const p=e.path[0];if(!p)return 1;const dx=p.x-e.x,dz=p.z-e.z,dd=Math.hypot(dx,dz),st=sp*dt;e.mv=1;
 if(dd<=st+.05){e.x=p.x;e.z=p.z;e.y=p.y;e.path.shift()}else{e.x+=dx/dd*st;e.z+=dz/dd*st;e.y+=(p.y-e.y)*st/dd;e.yaw=Math.atan2(-dx,-dz)}return e.path.length==0}
function sight(a,b){if(Math.abs(a.y-b.y)>2)return 0;return lclear(a.x,a.z,b.x,b.z,Math.min(a.y,b.y),b.cr?.9:1.5)}
function hide(e,f){if(f.used&&f.used!==e)return;if(f.k!='c'&&e.isP&&!e.cr){say('Присядьте, чтобы залезть под '+(f.k=='b'?'кровать':'стол'));return}
 e.px=e.x;e.pz=e.z;e.py=e.y;e.hid=f;f.used=e;e.hidT=0;e.x=f.x;e.z=f.z;e.y=f.y}
function unhide(e){if(!e.hid)return;e.hid.used=null;e.hid=null;e.x=e.px;e.z=e.pz;e.y=e.py;e.last=null}
function use(){if(P.hid){unhide(P);return}let b=null,bd=1.9;for(const f of furn)if(Math.abs(f.y-P.y)<2){const d=Math.hypot(f.x-P.x,f.z-P.z);if(d<bd){bd=d;b=f}}if(b)hide(P,b);else say('Рядом нет укрытия')}
function shootH(){if(P.cd>0||!P.gun||P.hid)return;if(P.am<=0){say('Нет патронов');P.cd=.6;return}P.am--;const sg=P.gun=='sg';P.cd=sg?1.1:.5;const o={x:P.x,y:P.y+1.55,z:P.z};beep(sg?90:170,.15,'sawtooth',.08);gunM.position.z=-.45;evs.push({x:P.x,y:P.y,z:P.z,r:25,t:5});
 const hs=new Set();for(let i=0;i<(sg?5:1);i++){const d=angDir(yaw+(sg?RN(-.06,.06):0),pitch+(sg?RN(-.05,.05):0)),r=ray(o,d,sg?14:40,P);line({x:o.x,y:o.y-.15,z:o.z},r,0xffee66);if(r.e)hs.add(r.e)}
 hs.forEach(e=>{if(e.isM){M.hp-=sg?1:.2;M.stun=.6;if(M.hp<=0){M.state='wait';M.t=30;M.alive=0;M.g.visible=false;say('Монстр убит! Но он вернётся…')}}else{if(e.hid)unhide(e);e.alive=0;e.g.visible=false;say(e.name+' убит')}})}
function mHit(e){e.inv=2;e.lives--;M.stun=1.3;if(e.isP){flash();beep(70,.3,'sawtooth',.1);if(e.hid)unhide(e);if(e.lives<=0){e.alive=0;over=1;$('end').innerHTML='<h2>💀 Вы погибли<br>Волн пережито: '+(waves-1)+'</h2>';endBtns()}else say('Монстр ударил! Осталось жизней: '+e.lives)}
 else if(e.lives<=0){e.alive=0;e.g.visible=false;if(e.hid){e.hid.used=null;e.hid=null}say(e.name+' погиб')}}
function mAI(dt){if(M.stun>0){M.stun-=dt;return}let tg=null,best=1e9,md='patrol';
 for(const e of ents){if(e.isM||!e.alive)continue;const d=Math.hypot(e.x-M.x,e.z-M.z);if(Math.abs(e.y-M.y)>2.5)continue;
  const seen=d<14&&sight(M,e)&&(!e.hid||(e.hid.k!='c'&&d<1.8)),heard=!e.hid&&d<e.noise;if((seen||heard)&&d<best){best=d;tg=e;md=seen?'chase':'hear'}}
 if(!tg)for(const v of evs)if(Math.abs(v.y-M.y)<2.5&&Math.hypot(v.x-M.x,v.z-M.z)<v.r){tg={x:v.x,y:v.y,z:v.z};md='hear';break}
 if(tg){M.dest={x:tg.x,y:tg.y,z:tg.z}}else if(!M.dest||M.path&&M.path.length==0&&Math.hypot(M.dest.x-M.x,M.dest.z-M.z)<1.5){const n=pick(nodes);M.dest={x:n.x,y:n.y,z:n.z}}
 navStep(M,M.dest,md=='chase'?5.2:md=='hear'?3.6:2.4,dt);
 for(const e of ents){if(e.isM||!e.alive||e.inv>0)continue;const d=Math.hypot(e.x-M.x,e.z-M.z);if(d<1.15&&Math.abs(e.y-M.y)<2&&!(e.hid&&(e.hid.k=='c'||d>1.8)))mHit(e)}}
function botH(b,dt){b.cr=1;b.mv=0;
 if(b.hid){b.hidT+=dt;if(b.hidT>(b.hid.k=='c'?20:999)||(M.state=='wait'&&M.t>12&&b.hidT>3)){b.last=b.hid;unhide(b);b.last=b.hid||b.last}return}
 if(M.state=='on'||M.t<8){if(!b.spot||b.spot.used&&b.spot.used!==b){let bd=1e9;b.spot=null;for(const f of furn)if(!f.used&&f!==b.last){const d=Math.hypot(f.x-b.x,f.z-b.z)+Math.abs(f.y-b.y)*5;if(d<bd){bd=d;b.spot=f}}}
  if(b.spot){navStep(b,b.spot,3.2,dt);if(Math.hypot(b.spot.x-b.x,b.spot.z-b.z)<.7&&Math.abs(b.spot.y-b.y)<1){hide(b,b.spot);b.spot=null}}}
 else{b.spot=null;if(!b.dest||navStep(b,b.dest,2,dt)){const n=pick(nodes);b.dest={x:n.x,y:n.y,z:n.z}}}}
function hUpdate(dt){M.t-=dt;
 if(M.state=='wait'&&M.t<=0){M.state='on';M.t=30;M.alive=1;M.hp=4;M.g.visible=true;M.x=12;M.z=18.4;M.y=0;M.path=null;M.dest=null;M.stun=1;waves++;say('Монстр вошёл в дом!');beep(60,.5,'sawtooth',.1)}
 else if(M.state=='on'&&M.t<=0){M.state='wait';M.t=30;M.alive=0;M.g.visible=false;say('Монстр ушёл…')}
 for(let i=evs.length-1;i>=0;i--){evs[i].t-=dt;if(evs[i].t<=0)evs.splice(i,1)}
 for(const c of creaks)c.cd-=dt;
 for(const e of ents){if(e.isM||!e.alive)continue;e.inv-=dt;e.cd-=dt;
  if(e.isP)ctl(dt);else botH(e,dt);
  e.noise=e.hid||!e.mv?0:e.cr?0:e.run?14:7;
  if(e.isP&&e.hid){e.hidT+=dt;if(e.hid.k=='c'&&e.hidT>20){unhide(e);say('Время в шкафу вышло!')}}
  if(!e.cr&&e.mv&&!e.hid)for(const c of creaks)if(c.cd<=0&&Math.abs(c.y-e.y)<1.5&&Math.hypot(c.x-e.x,c.z-e.z)<.9){c.cd=4;evs.push({x:c.x,y:c.y,z:c.z,r:22,t:6});beep(200,.25,'sawtooth',.06);if(e.isP)say('Скрип половицы!')}
  if(e.isP)for(const it of items)if(!it.got&&Math.abs(it.y-e.y)<1.5&&Math.hypot(it.x-e.x,it.z-e.z)<1.1){it.got=1;it.m.visible=false;
   if(it.k=='gun'){e.gun=it.g;e.am+=4;say(it.g=='sg'?'Найден дробовик!':'Найден пистолет!');gunM.visible=true}else if(it.k=='am'){e.am+=4;say('Патроны +4')}else{e.lives=Math.min(3,e.lives+1);say('Аптечка! Жизней: '+e.lives)}}}
 if(M.alive)mAI(dt);
 gunM.visible=!!P.gun&&!P.hid}
function startHorror(n){init();mode='horror';nH=n;house();scene.background=new T.Color(0);scene.fog=new T.Fog(0,2,24);scene.add(new T.AmbientLight(0x303048,1.4));
 const sl=new T.SpotLight(0xffffff,3,28,.7,.5);sl.position.set(0,0,0);sl.target.position.set(0,0,-5);cam.add(sl,sl.target);
 P=mk({isP:1,c:0x2255cc,name:'Вы'});P.g.visible=false;P.x=12;P.z=17;P.am=0;P.gun=null;ents=[P];
 for(let i=1;i<n;i++){const b=mk({isB:1,c:[0xcc3333,0x33aa33,0xccaa22][i-1],name:'Бот '+i});b.x=[10,14,12][i-1];b.z=[17,17,15.5][i-1];ents.push(b)}
 const g=new T.Group();const bd=new T.Mesh(new T.BoxGeometry(.9,2.2,.6),mat(0x111111));bd.position.y=1.1;g.add(bd);[-.2,.2].forEach(x=>{const e=new T.Mesh(new T.BoxGeometry(.12,.1,.1),bas(0xff0000));e.position.set(x,1.9,-.31);g.add(e)});g.visible=false;scene.add(g);
 M={g,isM:1,alive:0,state:'wait',t:30,hp:4,x:12,y:0,z:18.4,vy:0,yaw:0,cr:0,stun:0,hid:null};ents.push(M);
 const sp=ISP.slice().sort(()=>Math.random()-.5);sp.slice(0,6).forEach((p,i)=>{const k=i==0?'gun':i<3?'am':'med',c=k=='gun'?0x999999:k=='am'?0xffcc00:0xffffff,m=new T.Mesh(new T.BoxGeometry(.5,.3,.5),bas(i>2?0xff3344:c));m.position.set(p[0],p[2]+.3,p[1]);scene.add(m);items.push({k,g:pick(['sg','pi']),x:p[0],z:p[1],y:p[2],m})});
 CRK.slice().sort(()=>Math.random()-.5).slice(0,2).forEach(c=>creaks.push({x:c[0],z:c[1],y:c[2],cd:0}));
 $('b_ham').style.display='none';$('b_use').style.display='flex';gunM.visible=false;again=()=>startHorror(n);say('Выживите. Приседайте — тихо. E — спрятаться.');hud()}

// ---------- ОБЩЕЕ ----------
function init(){scene=new T.Scene();boxes=[];ents=[];clouds=[];fxs=[];items=[];furn=[];creaks=[];evs=[];nodes=[];over=0;paused=0;waves=0;P=null;M=null;cam.clear();scene.add(cam);cam.add(gunM);Object.keys(adm).forEach(k=>adm[k]=0);inp.run=0;$('b_run').style.background='';$('b_crouch').style.background='';
 ['menu','maps','hs','end','up','adm'].forEach(i=>$(i).classList.add('h'));$('ui').style.display='block';cam.position.set(0,0,0)}
function hud(){if(!P)return;let h;if(mode=='horror'){h=`${'❤'.repeat(Math.max(0,P.lives))} &nbsp; ${P.gun?(P.gun=='sg'?'Дробовик':'Пистолет')+' · патроны '+P.am:'Кулаки'+(P.am?' (патроны '+P.am+')':'')}<br>${M.state=='on'?'👹 Монстр в доме: '+Math.ceil(M.t)+'с':'Монстр придёт через '+Math.ceil(M.t)+'с'} · волна ${waves}`+(P.hid?`<br>Спрятаны · E — выйти${P.hid.k=='c'?' ('+Math.max(0,Math.ceil(20-P.hidT))+'с)':''}`:'')+(nH>1?'<br>'+ents.filter(e=>e.isB).map(e=>e.name+(e.alive?' '+'❤'.repeat(e.lives):' ✖')).join(' · '):'')}
 else h=`❤ ${Math.ceil(Math.max(0,P.hp))}/${P.maxhp} &nbsp; 🔫 ${P.rl>0?'перезарядка…':(adm.inf?'∞':P.mag)+'/'+P.s.mag}<br>${ents.map(e=>e.name+': '+e.k).join(' · ')}`;$('hud').innerHTML=h}
function endBtns(){const el=$('end');[['Ещё раз',()=>again()],['В меню',openMenu]].forEach(([t,f])=>{const b=document.createElement('button');b.textContent=t;b.onclick=f;el.appendChild(b)});el.classList.remove('h')}
function sync(){for(const e of ents){e.g.position.set(e.x,e.y,e.z);e.g.rotation.y=e.yaw;if(!e.isM)e.g.visible=!!e.alive&&!e.isP&&!e.hid;if(e.xr)e.xr.visible=!!adm.xr&&!e.isP}}
let last=performance.now();
function loop(t){requestAnimationFrame(loop);const dt=Math.min(.05,(t-last)/1000);last=t;if(!scene||!mode)return;
 if(!paused&&!over){if(mode=='horror')hUpdate(dt);else aUpdate(dt);for(let i=fxs.length-1;i>=0;i--){fxs[i].t-=dt;if(fxs[i].t<=0){scene.remove(fxs[i].m);fxs.splice(i,1)}}}
 if(msgT>0){msgT-=dt;if(msgT<=0)$('msg').textContent=''}
 gunM.position.z+=(-.6-gunM.position.z)*Math.min(1,dt*12);
 sync();hudT-=dt;if(hudT<=0){hudT=.12;hud()}
 const eye=P.hid?(P.hid.k=='c'?1.6:.45):(P.cr?1:1.6);cam.position.set(P.x,P.y+eye,P.z);cam.rotation.set(pitch,yaw,0,'YXZ');ren.render(scene,cam)}
requestAnimationFrame(loop);

// ---------- ИНТЕРФЕЙС ----------
function ovr(id,title,btns){const el=$(id);el.innerHTML='<h2>'+title+'</h2>';btns.forEach(([t,f])=>{const b=document.createElement('button');b.textContent=t;b.onclick=f;el.appendChild(b)});el.classList.remove('h')}
function openMenu(){mode='';P=null;$('ui').style.display='none';$('end').classList.add('h');$('hud').innerHTML='';ovr('menu','🎮 Выберите режим',[['🔫 Пистолет',()=>maps(0)],['🛠 Песочница',()=>maps(1)],['👻 Хоррор',hs]])}
function maps(sb){$('menu').classList.add('h');ovr('maps','Выберите карту',[['Склад',0],['Крепость',1],['Лабиринт',2],['Каньон',3]].map(([t,k])=>[t,()=>startArena(k,sb)]).concat([['← Назад',openMenu]]))}
function hs(){$('menu').classList.add('h');ovr('hs','Сколько игроков?',[['Один',1],['Вдвоём (с ботом)',2],['Втроём',3],['Вчетвером',4]].map(([t,n])=>[t,()=>startHorror(n)]).concat([['← Назад',openMenu]]))}
const AD=[['fly','✈ Полёт'],['xr','👁 Видение сквозь стены'],['invis','🫥 Невидимость'],['inf','∞ Бесконечные пули'],['speed','⚡ Спидхак'],['god','🛡 Бессмертие'],['one','💥 Убийство с 1 выстрела']];
function admOpen(){if(mode!='sand')return;paused=1;const el=$('adm');el.innerHTML='<h3>🔨 Админка — игра на паузе</h3>';
 AD.forEach(([k,t])=>{const b=document.createElement('button'),u=()=>b.textContent=t+(adm[k]?' ✔':'');u();b.onclick=()=>{adm[k]=!adm[k];u()};el.appendChild(b)});
 [['⭐ Случайное улучшение',()=>pick(UP)[1](P.s)],['❤ Вылечить',()=>P.hp=P.maxhp],['☠ Убить ботов',()=>ents.forEach(e=>e.isB&&e.alive&&hurt(e,9999,P))],['▶ Закрыть',()=>{paused=0;el.classList.add('h')}]].forEach(([t,f])=>{const b=document.createElement('button');b.textContent=t;b.onclick=f;el.appendChild(b)});el.classList.remove('h')}
function btn(id,txt,css,dn,up){const b=document.createElement('div');b.className='b';b.id=id;b.textContent=txt;b.style.cssText=css;b.addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation();dn&&dn()});if(up)['pointerup','pointercancel','pointerleave'].forEach(n=>b.addEventListener(n,up));$('ui').appendChild(b)}
btn('b_fire','🔥','right:24px;bottom:70px;width:92px;height:92px;font-size:30px',()=>inp.fire=1,()=>inp.fire=0);
btn('b_jump','⤒','right:130px;bottom:24px',()=>inp.jump=1,()=>inp.jump=0);
btn('b_rl','R','right:130px;bottom:104px',()=>act('reload'));
btn('b_crouch','Сесть','right:24px;bottom:176px',()=>act('crouch'));
btn('b_run','Бег','left:200px;bottom:30px',()=>act('run'));
btn('b_use','E','right:130px;bottom:184px;display:none',()=>act('use'));
btn('b_ham','🔨','right:20px;top:14px;display:none;width:50px;height:50px;font-size:24px',admOpen);
btn('b_menu','☰','left:14px;top:14px;width:46px;height:46px;font-size:22px',openMenu);
const js=$('js'),kn=$('kn');let jid=null;
function jm(e){const r=js.getBoundingClientRect();let dx=(e.clientX-r.left-r.width/2)/55,dy=(e.clientY-r.top-r.height/2)/55;const l=Math.hypot(dx,dy);if(l>1){dx/=l;dy/=l}inp.mx=dx;inp.mz=-dy;kn.style.transform=`translate(${dx*45}px,${dy*45}px)`}
js.addEventListener('pointerdown',e=>{e.preventDefault();jid=e.pointerId;js.setPointerCapture(jid);jm(e)});
js.addEventListener('pointermove',e=>{if(e.pointerId===jid)jm(e)});
const je=e=>{if(e.pointerId===jid){jid=null;inp.mx=inp.mz=0;kn.style.transform=''}};js.addEventListener('pointerup',je);js.addEventListener('pointercancel',je);
const lk=$('lk');let lid=null,lx=0,ly=0;
lk.addEventListener('pointerdown',e=>{if(lid===null){lid=e.pointerId;lx=e.clientX;ly=e.clientY;lk.setPointerCapture(lid)}});
lk.addEventListener('pointermove',e=>{if(e.pointerId===lid){yaw-=(e.clientX-lx)*.006;pitch=Math.max(-1.4,Math.min(1.4,pitch-(e.clientY-ly)*.006));lx=e.clientX;ly=e.clientY}});
['pointerup','pointercancel'].forEach(n=>lk.addEventListener(n,e=>{if(e.pointerId===lid)lid=null}));
openMenu();
