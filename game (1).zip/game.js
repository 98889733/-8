import * as T from './three.module.js';
const $=i=>document.getElementById(i),RN=(a,b)=>a+Math.random()*(b-a),pick=a=>a[Math.floor(Math.random()*a.length)],shuf=a=>a.slice().sort(()=>Math.random()-.5);
const ren=new T.WebGLRenderer({antialias:false});ren.setPixelRatio(Math.min(devicePixelRatio,1.5));ren.setSize(innerWidth,innerHeight);document.body.prepend(ren.domElement);
const cam=new T.PerspectiveCamera(75,innerWidth/innerHeight,.1,110);
addEventListener('resize',()=>{ren.setSize(innerWidth,innerHeight);cam.aspect=innerWidth/innerHeight;cam.updateProjectionMatrix()});
const MAT={},mat=c=>MAT[c]||(MAT[c]=new T.MeshLambertMaterial({color:c})),bas=(c,o={})=>new T.MeshBasicMaterial(Object.assign({color:c},o));
const W=40,D=30,H=3.4,EMPTY=[];
let scene,houses,ents,fxs,P,M,over=0,yaw=0,pitch=0,items,furn,creaks,evs,nodesAll,waves=0,msgT=0,hudT=0,cur=0,nH=1,mode='',amb,spot,pl,lampMat,lv=1,again=()=>{};
const inp={mx:0,mz:0,fire:0,run:0,jump:0};
const gunM=new T.Mesh(new T.BoxGeometry(.12,.14,.6),mat(0x222222));gunM.position.set(.3,-.28,-.6);
let AC;const beep=(f,d,tp='square',v=.04)=>{try{AC=AC||new AudioContext();const o=AC.createOscillator(),g=AC.createGain();o.type=tp;o.frequency.value=f;g.gain.value=v;o.connect(g);g.connect(AC.destination);o.start();o.stop(AC.currentTime+d)}catch(e){}};
const say=t=>{$('msg').textContent=t;msgT=3},flash=()=>{const f=$('fl');f.style.opacity=.6;setTimeout(()=>f.style.opacity=0,150)};
const hOf=x=>Math.floor(x/W),bx=x=>{const h=houses.get(hOf(x));return h?h.boxes:EMPTY};

// ---------- ФИЗИКА ----------
const RAD=.3;
const blocked=(x,z,y,h)=>{for(const b of bx(x))if(x+RAD>b.x0&&x-RAD<b.x1&&z+RAD>b.z0&&z-RAD<b.z1&&y+h>b.y0&&y+.55<b.y1)return 1;return 0};
const ground=(x,z,y)=>{let g=-99;for(const b of bx(x))if(x>b.x0-.2&&x<b.x1+.2&&z>b.z0-.2&&z<b.z1+.2&&b.y1<=y+.6&&b.y1>g)g=b.y1;return g};
function phys(e,vx,vz,dt){const h=e.cr?1.1:1.8;const nx=e.x+vx*dt;if(!blocked(nx,e.z,e.y,h))e.x=nx;const nz=e.z+vz*dt;if(!blocked(e.x,nz,e.y,h))e.z=nz;
 e.vy-=24*dt;const ny=e.y+e.vy*dt,g=ground(e.x,e.z,e.y);if(ny<=g){e.y=g;e.vy=0;e.gr=1}else{e.y=ny;e.gr=0}}
function ray(o,d,R,sh){let x,y,z;for(let t=.3;t<=R;t+=.25){x=o.x+d.x*t;y=o.y+d.y*t;z=o.z+d.z*t;
 for(const b of bx(x))if(x>b.x0&&x<b.x1&&y>b.y0&&y<b.y1&&z>b.z0&&z<b.z1)return{x,y,z};
 for(const e of ents)if(e!==sh&&e.alive&&!e.hid){const dx=e.x-x,dz=e.z-z;if(dx*dx+dz*dz<.3&&y>e.y&&y<e.y+(e.isM?2.3:e.cr?1.2:1.9))return{x,y,z,e}}}return{x,y,z}}
function line(a,b,c){const g=new T.BufferGeometry().setFromPoints([new T.Vector3(a.x,a.y,a.z),new T.Vector3(b.x,b.y,b.z)]);const l=new T.Line(g,new T.LineBasicMaterial({color:c}));scene.add(l);fxs.push({m:l,t:.08})}
const angDir=(y,p)=>({x:-Math.sin(y)*Math.cos(p),y:Math.sin(p),z:-Math.cos(y)*Math.cos(p)});
function lclear(x1,z1,x2,z2,y,h=1.2){const d=Math.hypot(x2-x1,z2-z1),n=Math.ceil(d/.35);for(let i=0;i<=n;i++){const x=x1+(x2-x1)*i/n,z=z1+(z2-z1)*i/n;for(const b of bx(x))if(b.s&&x>b.x0&&x<b.x1&&z>b.z0&&z<b.z1&&y+h>b.y0&&y+h<b.y1)return 0}return 1}

// ---------- МОДЕЛИ ----------
const limb=(m,len,w,x,y,z)=>{const pv=new T.Group();pv.position.set(x,y,z);const l=new T.Mesh(new T.BoxGeometry(w,len,w),m);l.position.y=-len/2;pv.add(l);return pv};
const prt=(geo,m,x,y,z,sx=1,sy=1,sz=1)=>{const p=new T.Mesh(geo,m);p.position.set(x,y,z);p.scale.set(sx,sy,sz);return p};
function mk(o){const g=new T.Group(),sk=mat(0xe0b890),cl=mat(o.c||0x3355aa),pn=mat(o.p||0x2a2a3a),hr=mat(o.h||0x3a2a1a),bk=bas(0x000000);
 const lL=limb(pn,.82,.2,-.14,.85,0),lR=limb(pn,.82,.2,.14,.85,0),aL=limb(cl,.7,.14,-.34,1.46,0),aR=limb(cl,.7,.14,.34,1.46,0);
 g.add(lL,lR,aL,aR,prt(new T.BoxGeometry(.5,.66,.3),cl,0,1.17,0),prt(new T.SphereGeometry(.2,10,8),sk,0,1.66,0),prt(new T.SphereGeometry(.215,10,6,0,6.3,0,1.7),hr,0,1.69,0),
  prt(new T.SphereGeometry(.03,6,4),bk,-.07,1.68,-.18),prt(new T.SphereGeometry(.03,6,4),bk,.07,1.68,-.18));
 const xr=prt(new T.BoxGeometry(.9,1.9,.7),bas(0xff2222,{transparent:true,opacity:.0}),0,.95,0);g.add(xr);scene.add(g);
 return Object.assign({g,parts:{lL,lR,aL,aR},x:0,y:0,z:0,vy:0,yaw:0,alive:1,cd:0,cr:0,gr:0,lives:3,inv:0,hid:null,hidT:0,ph:0,mv:0,noise:0},o)}
function monsterModel(){const g=new T.Group(),sk=mat(0x8a8f96),dk=mat(0x14141c),bn=mat(0xd8d2c0),eye=bas(0xff2200),mt=bas(0x330000);
 const lL=limb(dk,1.1,.2,-.2,1.1,0),lR=limb(dk,1.1,.2,.2,1.1,0),aL=limb(sk,1.7,.13,-.5,1.95,0),aR=limb(sk,1.7,.13,.5,1.95,0);
 for(const a of[aL,aR]){for(let i=-1;i<=1;i++){const c=new T.Mesh(new T.ConeGeometry(.04,.4,5),bn);c.position.set(i*.05,-1.9,0);c.rotation.x=Math.PI;a.add(c)}}
 const head=new T.Group();head.position.set(0,2.15,-.1);head.add(prt(new T.SphereGeometry(.28,12,10),sk,0,0,0,.9,1.45,1),prt(new T.SphereGeometry(.07,8,6),eye,-.11,.08,-.24),prt(new T.SphereGeometry(.07,8,6),eye,.11,.08,-.24),
  prt(new T.BoxGeometry(.2,.16,.06),mt,0,-.22,-.22));for(let i=-2;i<=2;i++)head.add(prt(new T.ConeGeometry(.018,.1,4),bn,i*.04,-.3,-.23,1,1,1));
 g.add(lL,lR,aL,aR,head,prt(new T.CylinderGeometry(.3,.2,1.2,8),sk,0,1.55,.05,1,1,.7),prt(new T.CylinderGeometry(.22,.3,.5,8),dk,0,.95,.05));
 for(let i=0;i<5;i++){const s=new T.Mesh(new T.ConeGeometry(.07,.45,5),bn);s.position.set((i-2)*.1,1.8-Math.abs(i-2)*.2,.3);s.rotation.x=1.2;g.add(s)}
 g.userData={lL,lR,aL,aR,head};return g}

// ---------- ДОМ (бесконечная цепочка) ----------
const NL=[['ent',20,29,0],['hl',6,22.5,0],['hm',20,23,0],['hr',34,22.5,0],['A',3,27,0],['C',37.5,27,0],['dk',6.5,20,0],['dl',20.5,20,0],['dg',33.5,20,0],['k',7,10,0],['l',20,10,0],['g',33,10,0],['kl',14,10,0],['lg',27,10,0],['pW',1.5,23.5,0],['pE',38.5,23.5,0],
 ['uB',13.5,27,H],['u1',8,23,H],['ud1',16,23.5,H],['u2',22,24,H],['ud2',28,23.5,H],['u3',34,24,H],['upW',1.5,23.5,H],['upE',38.5,23.5,H],['ub1',4,20,H],['ub2',15,20,H],['ub3',25,20,H],['ub4',35,20,H],['ur1',5,10,H],['ur2',15,10,H],['ur3',25,10,H],['ur4',35,10,H],['ui1',10,10,H],['ui2',20,10,H],['ui3',30,10,H],
 ['bD',28,27,-H],['b1',33,22,-H],['b2',33,8,-H],['b3',26,22,-H],['b4',26,10,-H],['b5',20,22,-H],['b6',20,8,-H],['b7',14,22,-H],['b8',14,10,-H],['b9',7,22,-H],['b10',7,8,-H]];
const FUR=[['c',1.2,3,0],['t',7,12,0],['c',12.8,18,0],['t',20,6,0],['c',26,2,0],['b',35,4,0],['b',35,15,0],['c',38.8,10,0],['t',30,24,0],['c',1.2,28.4,0],['c',38.8,28.4,0],
 ['b',5,4,H],['c',1.2,13,H],['b',15,4,H],['c',12,18.5,H],['b',25,4,H],['t',25,14,H],['b',35,4,H],['c',38.8,16,H],['t',22,25,H],['c',14.8,29,H],['t',34,27,H],
 ['t',6,6,-H],['c',1.2,20,-H],['t',20,6,-H],['c',24.5,18,-H],['t',33,6,-H],['c',38.8,20,-H],['t',7,26,-H],['c',20,28.6,-H]];
const ISP=[[3,3,0],[37,3,0],[10,17,0],[30,17,0],[22,27,0],[6,24,0],[3,3,H],[17,3,H],[37,17,H],[22,27,H],[10,17,H],[3,28,H],[3,3,-H],[20,15,-H],[37,3,-H],[8,27,-H],[20,27,-H]];
const CRK=[[10,23,0],[30,23,0],[8,8,0],[32,8,0],[20,14,0],[10,23,H],[30,24,H],[5,12,H],[15,8,H],[25,12,H],[35,8,H],[20,14,-H]];
const LMP=[[7,10,0],[20,10,0],[33,10,0],[8,24,0],[20,24,0],[32,24,0],[5,10,H],[15,10,H],[25,10,H],[35,10,H],[8,24,H],[22,24,H],[34,24,H],[7,15,-H],[20,15,-H],[33,15,-H]];
function buildHouse(hi){const ox=hi*W,h={id:hi,boxes:[],vis:new Map(),grp:new T.Group(),nodes:[]};houses.set(hi,h);scene.add(h.grp);
 const V=(x0,y0,z0,x1,y1,z1,c)=>{let a=h.vis.get(c);if(!a)h.vis.set(c,a=[]);a.push([ox+(x0+x1)/2,(y0+y1)/2,(z0+z1)/2,x1-x0,y1-y0,z1-z0])};
 const B=(x0,y0,z0,x1,y1,z1,c,s=1)=>{h.boxes.push({x0:ox+x0,y0,z0,x1:ox+x1,y1,z1,s});V(x0,y0,z0,x1,y1,z1,c)};
 const seg=(lo,hi_,gaps,f)=>{let c=lo;for(const g of gaps.slice().sort((p,q)=>p[0]-q[0])){if(g[0]-c>.01)f(c,g[0]);c=g[1]}if(hi_-c>.01)f(c,hi_)};
 const wX=(z,xa,xb,y,gaps,c)=>seg(xa,xb,gaps,(a,b)=>B(a,y,z-.15,b,y+H,z+.15,c)),wZ=(x,za,zb,y,gaps,c)=>seg(za,zb,gaps,(a,b)=>B(x-.15,y,a,x+.15,y+H,b,c));
 const slab=(y0,y1,hx0,hz0,hx1,hz1,c)=>{B(0,y0,0,W,y1,hz0,c,0);B(0,y0,hz1,W,y1,D,c,0);B(0,y0,hz0,hx0,y1,hz1,c,0);B(hx1,y0,hz0,W,y1,hz1,c,0)};
 B(0,-H-.3,0,W,-H,D,0x2c2c30,0);slab(-.3,0,27.6,25.6,36.4,28.4,0x5a3e28);slab(H-.3,H,3.6,25.6,12,28.4,0x4a3a2e);B(0,2*H,0,W,2*H+.3,D,0x222226,0);
 const OC=0x6e5a48,IG=0xa39580,IU=0x8c98a8,IB=0x5b6068;
 for(const y of[-H,0,H]){const pas=y>=0?[[22,25]]:[];wX(0,0,W,y,[],OC);wX(D,0,W,y,[],OC);wZ(0,0,D,y,pas,OC);wZ(W,0,D,y,pas,OC)}
 wX(20,0,W,0,[[5,8],[19,22],[32,35]],IG);wZ(14,0,20,0,[[9,11]],IG);wZ(27,0,20,0,[[9,11]],IG);
 wX(20,0,W,H,[[3,5],[14,16],[24,26],[34,36]],IU);[10,20,30].forEach(x=>wZ(x,0,20,H,[[9,11]],IU));[16,28].forEach(x=>wZ(x,20,D,H,[[22,25]],IU));
 [14,26].forEach(x=>wZ(x,0,D,-H,[[9,11],[21,23]],IB));
 for(let i=0;i<8;i++)B(4+i,0,26,5+i,.425*(i+1),28,0x6e4b2a,0);for(let i=0;i<7;i++)B(35-i,-H,26,36-i,-.425*(i+1),28,0x5a4a3a,0);
 B(18,0,D-.4,22,2.7,D+.1,0x4a2410);V(21,1,D-.45,21.3,1.3,D-.35,0xd0b040);
 // ковры, картины, плинтус
 [[2,2,12,18,0x7a2a2a],[16,2,26,18,0x2a4a7a],[29,2,39,18,0x2a6a4a],[8,23,32,27.5,0x6a3a5a]].forEach(r=>V(r[0],.01,r[1],r[2],.04,r[3],r[4]));
 [[6,.16,0x2a5a8a],[16,.16,0xa04030],[24,.16,0x4a8a4a],[34,.16,0xb09030]].forEach(p=>{V(p[0],1.4,p[1],p[0]+2.2,2.5,p[1]+.1,p[2]);V(p[0],H+1.4,p[1],p[0]+2.2,H+2.5,p[1]+.1,p[2])});
 for(const y of[0,H,-H]){V(0,y,.15,W,y+.15,.25,0x2a2218);V(0,y,D-.25,W,y+.15,D-.15,0x2a2218)}
 // мебель
 FUR.forEach(([k,x,z,y])=>{h.fur=h.fur||[];const f={k,x:ox+x,z,y,h:hi};furn.push(f);
  if(k=='c'){B(x-.5,y,z-.35,x+.5,y+2.1,z+.35,0x5e3a1e);V(x-.03,y+.9,z-.37,x+.03,y+1.2,z-.34,0xd0b040)}
  else if(k=='t'){V(x-.75,y+.7,z-.45,x+.75,y+.78,z+.45,0x8a5a2a);for(const a of[-.65,.65])for(const b of[-.35,.35])V(x+a-.04,y,z+b-.04,x+a+.04,y+.7,z+b+.04,0x6a4220)}
  else{B(x-.55,y,z-1,x+.55,y+.45,z+1,0x7a3a4a,0);V(x-.55,y+.45,z+.55,x+.55,y+.52,z+.95,0xeeeeee);V(x-.57,y,z-1.05,x+.57,y+.9,z-.97,0x4a2a1a)}});
 // свет
 LMP.forEach(([x,z,y])=>{const m=new T.Mesh(new T.BoxGeometry(.6,.1,.6),lampMat);m.position.set(ox+x,y+H-.12,z);h.grp.add(m)});
 // узлы
 const nm={};NL.forEach(([n,x,z,y])=>{const o={x:ox+x,z,y,adj:[],h:hi};nm[n]=o;h.nodes.push(o)});h.nm=nm;
 h.nodes.forEach((a,i)=>{for(let j=i+1;j<h.nodes.length;j++){const b=h.nodes[j];if(Math.abs(a.y-b.y)<1&&Math.hypot(a.x-b.x,a.z-b.z)<16&&lclear(a.x,a.z,b.x,b.z,a.y)){a.adj.push(b);b.adj.push(a)}}});
 [['A','uB'],['C','bD']].forEach(([a,b])=>{nm[a].adj.push(nm[b]);nm[b].adj.push(nm[a])});
 // предметы и скрипы
 const sp=shuf(ISP);const cnt=hi==0?[['gun',1],['am',2],['med',2]]:[['gun',Math.random()<.4?1:0],['am',2],['med',Math.random()<.6?1:0]];let si=0;
 cnt.forEach(([k,n])=>{for(let i=0;i<n;i++){const p=sp[si++],m=new T.Mesh(new T.BoxGeometry(.5,.3,.5),bas(k=='gun'?0xaaaaaa:k=='am'?0xffcc00:0xff3344));m.position.set(ox+p[0],p[2]+.3,p[1]);h.grp.add(m);items.push({k,g:pick(['sg','pi']),x:ox+p[0],z:p[1],y:p[2],m,h:hi})}});
 shuf(CRK).slice(0,3).forEach(c=>creaks.push({x:ox+c[0],z:c[1],y:c[2],cd:0,h:hi}));
 // инстансы
 const d=new T.Object3D();h.vis.forEach((arr,c)=>{const im=new T.InstancedMesh(new T.BoxGeometry(1,1,1),mat(c),arr.length);im.frustumCulled=false;arr.forEach((a,i)=>{d.position.set(a[0],a[1],a[2]);d.scale.set(a[3],a[4],a[5]);d.updateMatrix();im.setMatrixAt(i,d.matrix)});h.grp.add(im)});h.vis=null;
 refreshNodes()}
function refreshNodes(){nodesAll=[...houses.values()].flatMap(h=>h.nodes);nodesAll.forEach(n=>n.adj=n.adj.filter(a=>houses.has(a.h)));
 for(const[id,h]of houses){const n=houses.get(id+1);if(n)for(const[a,b]of[['pE','pW'],['upE','upW']]){const x=h.nm[a],y=n.nm[b];if(!x.adj.includes(y)){x.adj.push(y);y.adj.push(x)}}}}
function removeHouse(id){const h=houses.get(id);scene.remove(h.grp);h.grp.traverse(o=>{if(o.geometry)o.geometry.dispose()});houses.delete(id);
 for(const arr of[furn,items,creaks]){for(let i=arr.length-1;i>=0;i--)if(arr[i].h===id)arr.splice(i,1)}
 for(const e of ents)if(!e.isP&&hOf(e.x)===id){e.hid=null;e.x=cur*W+20;e.z=24;e.y=0;e.path=null}refreshNodes()}
function ensure(c){cur=c;for(let h=c-1;h<=c+1;h++)if(!houses.has(h))buildHouse(h);for(const id of[...houses.keys()])if(Math.abs(id-c)>1)removeHouse(id)}

// ---------- НАВИГАЦИЯ ----------
function near(p){let bi=null,bd=1e9,fb=null,fd=1e9;for(const n of nodesAll){if(Math.abs(n.y-p.y)>2||Math.abs(n.x-p.x)>30)continue;const d=Math.hypot(n.x-p.x,n.z-p.z);if(d<fd){fd=d;fb=n}if(d<bd&&d<22&&lclear(p.x,p.z,n.x,n.z,p.y)){bd=d;bi=n}}return bi||fb}
function route(e,d){const a=near(e),b=near(d),fin={x:d.x,y:d.y,z:d.z};if(!a||!b)return[fin];for(const n of nodesAll){n.d=1e9;n.pv=null;n.dn=0}a.d=0;
 for(;;){let u=null;for(const n of nodesAll)if(!n.dn&&(!u||n.d<u.d))u=n;if(!u||u.d>=1e9)break;u.dn=1;if(u===b)break;for(const v of u.adj){const w=u.d+Math.hypot(u.x-v.x,u.z-v.z)+Math.abs(u.y-v.y)*3;if(w<v.d){v.d=w;v.pv=u}}}
 const r=[];for(let c=b;c;c=c.pv)r.unshift({x:c.x,y:c.y,z:c.z});r.push(fin);return r}
function navStep(e,d,sp,dt){e.pt=(e.pt||0)-dt;if(!e.path||e.pt<=0||!e.pd||Math.hypot(e.pd.x-d.x,e.pd.z-d.z)>1.5||Math.abs(e.pd.y-d.y)>1.5){e.path=route(e,d);e.pd={x:d.x,y:d.y,z:d.z};e.pt=1.2}
 const p=e.path[0];if(!p)return 1;const dx=p.x-e.x,dz=p.z-e.z,dd=Math.hypot(dx,dz),st=sp*dt;e.mv=1;
 if(dd<=st+.05){e.x=p.x;e.z=p.z;e.y=p.y;e.path.shift()}else{e.x+=dx/dd*st;e.z+=dz/dd*st;e.y+=(p.y-e.y)*st/dd;e.yaw=Math.atan2(-dx,-dz)}return e.path.length==0}
const sight=(a,b)=>Math.abs(a.y-b.y)<=2&&lclear(a.x,a.z,b.x,b.z,Math.min(a.y,b.y),b.cr?.9:1.5);

// ---------- ИГРОВАЯ ЛОГИКА ----------
function hide(e,f){if(f.used&&f.used!==e)return;if(f.k!='c'&&e.isP&&!e.cr){say('Присядьте, чтобы залезть под '+(f.k=='b'?'кровать':'стол'));return}e.px=e.x;e.pz=e.z;e.py=e.y;e.hid=f;f.used=e;e.hidT=0;e.x=f.x;e.z=f.z;e.y=f.y}
function unhide(e){if(!e.hid)return;e.hid.used=null;e.hid=null;e.x=e.px;e.z=e.pz;e.y=e.py}
function use(){if(P.hid){unhide(P);return}let b=null,bd=1.9;for(const f of furn)if(Math.abs(f.y-P.y)<2){const d=Math.hypot(f.x-P.x,f.z-P.z);if(d<bd){bd=d;b=f}}if(b)hide(P,b);else say('Рядом нет укрытия')}
function shootH(){if(P.cd>0||!P.gun||P.hid)return;if(P.am<=0){say('Нет патронов');P.cd=.6;return}P.am--;const sg=P.gun=='sg';P.cd=sg?1.1:.5;const o={x:P.x,y:P.y+1.55,z:P.z};beep(sg?90:170,.15,'sawtooth',.08);gunM.position.z=-.45;evs.push({x:P.x,y:P.y,z:P.z,r:25,t:5});
 const hs=new Set();for(let i=0;i<(sg?5:1);i++){const d=angDir(yaw+(sg?RN(-.06,.06):0),pitch+(sg?RN(-.05,.05):0)),r=ray(o,d,sg?14:40,P);line({x:o.x,y:o.y-.15,z:o.z},r,0xffee66);if(r.e)hs.add(r.e)}
 hs.forEach(e=>{if(e.isM){M.hp-=sg?1:.2;M.stun=.6;if(M.hp<=0){M.state='wait';M.t=30;M.alive=0;M.g.visible=false;say('Монстр убит! Но он вернётся…')}}else{if(e.hid)unhide(e);e.alive=0;e.g.visible=false;say(e.name+' убит')}})}
function mHit(e){e.inv=2;e.lives--;M.stun=1.3;if(e.isP){flash();beep(70,.3,'sawtooth',.1);if(e.hid)unhide(e);if(e.lives<=0){e.alive=0;over=1;$('end').innerHTML='<h2>💀 Вы погибли<br>Волн пережито: '+Math.max(0,waves-1)+'</h2>';endBtns()}else say('Монстр ударил! Жизней: '+e.lives)}
 else if(e.lives<=0){e.alive=0;e.g.visible=false;if(e.hid){e.hid.used=null;e.hid=null}say(e.name+' погиб')}}
function mAI(dt){if(M.stun>0){M.stun-=dt;return}let tg=null,best=1e9,md='patrol';
 for(const e of ents){if(e.isM||!e.alive)continue;const d=Math.hypot(e.x-M.x,e.z-M.z);if(Math.abs(e.y-M.y)>2.5)continue;
  const seen=d<14&&sight(M,e)&&(!e.hid||(e.hid.k!='c'&&d<1.8)),heard=!e.hid&&d<e.noise;if((seen||heard)&&d<best){best=d;tg=e;md=seen?'chase':'hear'}}
 if(!tg)for(const v of evs)if(Math.abs(v.y-M.y)<2.5&&Math.hypot(v.x-M.x,v.z-M.z)<v.r){tg={x:v.x,y:v.y,z:v.z};md='hear';break}
 if(tg)M.dest={x:tg.x,y:tg.y,z:tg.z};else if(!M.dest||(M.path&&M.path.length==0)&&Math.hypot(M.dest.x-M.x,M.dest.z-M.z)<1.5){const ns=nodesAll.filter(n=>Math.abs(hOf(n.x)-cur)<=1),n=pick(ns);M.dest={x:n.x,y:n.y,z:n.z}}
 navStep(M,M.dest,md=='chase'?5.2:md=='hear'?3.6:2.4,dt);
 for(const e of ents){if(e.isM||!e.alive||e.inv>0)continue;const d=Math.hypot(e.x-M.x,e.z-M.z);if(d<1.2&&Math.abs(e.y-M.y)<2&&!(e.hid&&(e.hid.k=='c'||d>1.8)))mHit(e)}}
function botH(b,dt){b.cr=1;b.mv=0;
 if(b.hid){b.hidT+=dt;if(b.hidT>(b.hid.k=='c'?20:999)||(M.state=='wait'&&M.t>12&&b.hidT>3)){b.last=b.hid;unhide(b);b.last=b.last}return}
 if(M.state=='on'||M.t<8){if(!b.spot||(b.spot.used&&b.spot.used!==b)||!furn.includes(b.spot)){let bd=1e9;b.spot=null;for(const f of furn)if(!f.used&&f!==b.last){const d=Math.hypot(f.x-b.x,f.z-b.z)+Math.abs(f.y-b.y)*5;if(d<bd){bd=d;b.spot=f}}}
  if(b.spot){navStep(b,b.spot,3.2,dt);if(Math.hypot(b.spot.x-b.x,b.spot.z-b.z)<.7&&Math.abs(b.spot.y-b.y)<1){hide(b,b.spot);b.spot=null}}}
 else{b.spot=null;if(!b.dest||navStep(b,b.dest,2,dt)){const ns=nodesAll.filter(n=>Math.abs(hOf(n.x)-cur)<=1),n=pick(ns);b.dest={x:n.x,y:n.y,z:n.z}}}}
function ctl(dt){const e=P,f=inp.mz,r=inp.mx;e.mv=Math.hypot(f,r)>.15&&!e.hid;e.yaw=yaw;if(e.hid)return;
 const sp=e.cr?1.7:inp.run?6.2:3.6;e.run=inp.run&&!e.cr;if(inp.jump&&e.gr)e.vy=7;
 phys(e,(-Math.sin(yaw)*f+Math.cos(yaw)*r)*sp,(-Math.cos(yaw)*f-Math.sin(yaw)*r)*sp,dt);if(inp.fire)shootH()}
function hUpdate(dt){M.mv=0;M.t-=dt;
 if(M.state=='wait'&&M.t<=0){M.state='on';M.t=30;M.alive=1;M.hp=4;M.g.visible=true;M.x=cur*W+20;M.z=29;M.y=0;M.path=null;M.dest=null;M.stun=1;waves++;say('Свет погас — монстр вошёл в дом!');beep(60,.5,'sawtooth',.1)}
 else if(M.state=='on'&&M.t<=0){M.state='wait';M.t=30;M.alive=0;M.g.visible=false;say('Монстр ушёл… включился свет')}
 for(let i=evs.length-1;i>=0;i--){evs[i].t-=dt;if(evs[i].t<=0)evs.splice(i,1)}for(const c of creaks)c.cd-=dt;
 for(const e of ents){if(e.isM||!e.alive)continue;e.inv-=dt;e.cd-=dt;if(e.isP)ctl(dt);else botH(e,dt);
  e.noise=e.hid||!e.mv?0:e.cr?0:e.run?14:7;if(e.isP&&e.hid){e.hidT+=dt;if(e.hid.k=='c'&&e.hidT>20){unhide(e);say('Время в шкафу вышло!')}}
  if(!e.cr&&e.mv&&!e.hid)for(const c of creaks)if(c.cd<=0&&Math.abs(c.y-e.y)<1.5&&Math.hypot(c.x-e.x,c.z-e.z)<.9){c.cd=4;evs.push({x:c.x,y:c.y,z:c.z,r:22,t:6});beep(200,.25,'sawtooth',.06);if(e.isP)say('Скрип половицы!')}
  if(e.isP)for(const it of items)if(!it.got&&Math.abs(it.y-e.y)<1.5&&Math.hypot(it.x-e.x,it.z-e.z)<1.1){it.got=1;it.m.visible=false;
   if(it.k=='gun'){e.gun=it.g;e.am+=4;say(it.g=='sg'?'Найден дробовик!':'Найден пистолет!')}else if(it.k=='am'){e.am+=4;say('Патроны +4')}else{e.lives=Math.min(3,e.lives+1);say('Аптечка! Жизней: '+e.lives)}}}
 if(M.alive)mAI(dt);gunM.visible=!!P.gun&&!P.hid;ensure(hOf(P.x))}
function startHorror(n){mode='h';nH=n;scene=new T.Scene();houses=new Map();ents=[];fxs=[];items=[];furn=[];creaks=[];evs=[];nodesAll=[];over=0;waves=0;cur=0;lv=1;cam.clear();scene.add(cam);cam.add(gunM);
 ['menu','end'].forEach(i=>$(i).classList.add('h'));$('ui').style.display='block';
 lampMat=bas(0xffe9a8);scene.fog=new T.Fog(0x201a14,8,64);scene.background=new T.Color(0x201a14);amb=new T.AmbientLight(0xffe8c8,1.7);scene.add(amb);
 spot=new T.SpotLight(0xffffff,1,30,.7,.5);spot.position.set(0,0,0);spot.target.position.set(0,0,-5);cam.add(spot,spot.target);pl=new T.PointLight(0xff2200,0,10);scene.add(pl);
 P=mk({isP:1,c:0x2255cc,name:'Вы'});P.g.visible=false;P.x=20;P.z=26;P.y=0;P.am=0;P.gun=null;yaw=0;pitch=0;ents.push(P);
 for(let i=1;i<n;i++){const b=mk({isB:1,c:[0xcc3333,0x33aa33,0xccaa22][i-1],h:[0x111111,0xaa6622,0xdddd88][i-1],name:'Бот '+i});b.x=[17,23,20][i-1];b.z=[27,27,24][i-1];ents.push(b)}
 const g=monsterModel();g.visible=false;scene.add(g);M={g,isM:1,alive:0,state:'wait',t:30,hp:4,x:20,y:0,z:29,vy:0,yaw:0,cr:0,stun:0,hid:null,mv:0,ph:0,parts:g.userData};ents.push(M);
 ensure(0);gunM.visible=false;again=()=>startHorror(n);say('Свет горит — монстр придёт через 30 с. E — спрятаться, «Сесть» — тише.');hud()}
function act(a){if(!P||over)return;if(a=='use')use();if(a=='crouch'){P.cr=P.cr?0:1;$('b_crouch').style.background=P.cr?'#2b6':''}if(a=='run'){inp.run=inp.run?0:1;$('b_run').style.background=inp.run?'#2b6':''}}
function hud(){if(!P)return;$('hud').innerHTML=`${'❤'.repeat(Math.max(0,P.lives))} &nbsp; ${P.gun?(P.gun=='sg'?'Дробовик':'Пистолет')+' · патроны '+P.am:'Кулаки'+(P.am?' (патроны '+P.am+')':'')} &nbsp; 🏠 ${cur}<br>${M.state=='on'?'👹 Монстр в доме: '+Math.ceil(M.t)+'с':'💡 Свет горит · монстр через '+Math.ceil(M.t)+'с'} · волна ${waves}`+(P.hid?`<br>Спрятаны · E — выйти${P.hid.k=='c'?' ('+Math.max(0,Math.ceil(20-P.hidT))+'с)':''}`:'')+(nH>1?'<br>'+ents.filter(e=>e.isB).map(e=>e.name+(e.alive?' '+'❤'.repeat(e.lives):' ✖')).join(' · '):'')}
function endBtns(){const el=$('end');[['Ещё раз',()=>again()],['В меню',openMenu]].forEach(([t,f])=>{const b=document.createElement('button');b.textContent=t;b.onclick=f;el.appendChild(b)});el.classList.remove('h')}
function lights(dt){let L=M.state=='wait'?1:0;if(M.state=='wait'&&M.t<2.5){L=Math.random()<.5?1:0;lv=L}else lv+=(L-lv)*Math.min(1,dt*4);
 amb.intensity=.2+lv*1.5;scene.fog.near=2+lv*6;scene.fog.far=24+lv*42;const c=.13*lv;scene.fog.color.setRGB(c*1.2,c,c*.7);scene.background.copy(scene.fog.color);
 lampMat.color.setRGB(.12+.88*lv,.12+.8*lv,.1+.55*lv);spot.intensity=3.2*(1-.75*lv);pl.intensity=M.alive?1.6:0;pl.position.set(M.x,M.y+1.8,M.z)}
function anim(e,dt){const p=e.parts;if(!p)return;e.ph+=e.mv?dt*(e.isM?7:9):0;const s=e.mv?Math.sin(e.ph)*.7:0;p.lL.rotation.x=s;p.lR.rotation.x=-s;p.aL.rotation.x=-s*.8-(e.isM?.4:0);p.aR.rotation.x=s*.8-(e.isM?.4:0);
 if(e.isM){const hd=p.head;hd.rotation.z=Math.sin(performance.now()/300)*.15;hd.rotation.x=.2}}
function sync(dt){for(const e of ents){e.g.position.set(e.x,e.y,e.z);e.g.rotation.y=e.yaw;if(!e.isM)e.g.visible=!!e.alive&&!e.isP&&!e.hid;anim(e,dt)}}
let last=performance.now();
function loop(t){requestAnimationFrame(loop);const dt=Math.min(.05,(t-last)/1000);last=t;if(mode!='h')return;
 if(!over){hUpdate(dt);for(let i=fxs.length-1;i>=0;i--){fxs[i].t-=dt;if(fxs[i].t<=0){scene.remove(fxs[i].m);fxs.splice(i,1)}}}
 if(msgT>0){msgT-=dt;if(msgT<=0)$('msg').textContent=''}gunM.position.z+=(-.6-gunM.position.z)*Math.min(1,dt*12);
 lights(dt);sync(dt);hudT-=dt;if(hudT<=0){hudT=.12;hud()}
 const eye=P.hid?(P.hid.k=='c'?1.6:.45):(P.cr?1:1.6);cam.position.set(P.x,P.y+eye,P.z);cam.rotation.set(pitch,yaw,0,'YXZ');ren.render(scene,cam)}
requestAnimationFrame(loop);

// ---------- ИНТЕРФЕЙС ----------
function openMenu(){mode='';P=null;$('ui').style.display='none';$('end').classList.add('h');$('hud').innerHTML='';$('msg').textContent='';const el=$('menu');el.innerHTML='<h2>👻 Хоррор: бесконечный дом<br><small>Сколько игроков?</small></h2>';
 [['Один',1],['Вдвоём (с ботом)',2],['Втроём',3],['Вчетвером',4]].forEach(([t,n])=>{const b=document.createElement('button');b.textContent=t;b.onclick=()=>startHorror(n);el.appendChild(b)});el.classList.remove('h')}
function btn(id,txt,css,dn,up){const b=document.createElement('div');b.className='b';b.id=id;b.textContent=txt;b.style.cssText=css;b.addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation();dn&&dn()});if(up)['pointerup','pointercancel','pointerleave'].forEach(n=>b.addEventListener(n,up));$('ui').appendChild(b)}
btn('b_fire','🔥','right:24px;bottom:70px;width:92px;height:92px;font-size:30px',()=>inp.fire=1,()=>inp.fire=0);
btn('b_jump','⤒','right:130px;bottom:24px',()=>inp.jump=1,()=>inp.jump=0);
btn('b_crouch','Сесть','right:24px;bottom:176px',()=>act('crouch'));
btn('b_run','Бег','left:200px;bottom:30px',()=>act('run'));
btn('b_use','E','right:130px;bottom:104px',()=>act('use'));
btn('b_menu','☰','left:14px;top:14px;width:46px;height:46px;font-size:22px',openMenu);
const js=$('js'),kn=$('kn');let jid=null;
function jm(e){const r=js.getBoundingClientRect();let dx=(e.clientX-r.left-r.width/2)/55,dy=(e.clientY-r.top-r.height/2)/55;const l=Math.hypot(dx,dy);if(l>1){dx/=l;dy/=l}inp.mx=dx;inp.mz=-dy;kn.style.transform=`translate(${dx*45}px,${dy*45}px)`}
js.addEventListener('pointerdown',e=>{e.preventDefault();jid=e.pointerId;js.setPointerCapture(jid);jm(e)});js.addEventListener('pointermove',e=>{if(e.pointerId===jid)jm(e)});
const je=e=>{if(e.pointerId===jid){jid=null;inp.mx=inp.mz=0;kn.style.transform=''}};js.addEventListener('pointerup',je);js.addEventListener('pointercancel',je);
const lk=$('lk');let lid=null,lx=0,ly=0;
lk.addEventListener('pointerdown',e=>{if(lid===null){lid=e.pointerId;lx=e.clientX;ly=e.clientY;lk.setPointerCapture(lid)}});
lk.addEventListener('pointermove',e=>{if(e.pointerId===lid){yaw-=(e.clientX-lx)*.006;pitch=Math.max(-1.4,Math.min(1.4,pitch-(e.clientY-ly)*.006));lx=e.clientX;ly=e.clientY}});
['pointerup','pointercancel'].forEach(n=>lk.addEventListener(n,e=>{if(e.pointerId===lid)lid=null}));
openMenu();
