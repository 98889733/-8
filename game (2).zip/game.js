import * as T from './three.module.js';
const $=i=>document.getElementById(i),RN=(a,b)=>a+Math.random()*(b-a),pick=a=>a[Math.floor(Math.random()*a.length)],shuf=a=>a.slice().sort(()=>Math.random()-.5);
const ren=new T.WebGLRenderer({antialias:false});ren.setPixelRatio(Math.min(devicePixelRatio,1.5));ren.setSize(innerWidth,innerHeight);document.body.prepend(ren.domElement);
const cam=new T.PerspectiveCamera(75,innerWidth/innerHeight,.1,110);
addEventListener('resize',()=>{ren.setSize(innerWidth,innerHeight);cam.aspect=innerWidth/innerHeight;cam.updateProjectionMatrix()});
const MAT={},mat=c=>MAT[c]||(MAT[c]=new T.MeshLambertMaterial({color:c})),bas=(c,o={})=>new T.MeshBasicMaterial(Object.assign({color:c},o));
const W=40,D=30,H=3.4,EMPTY=[];
let scene,houses,ents,fxs,P,M,over=0,yaw=0,pitch=0,items,furn,creaks,evs,nodesAll,waves=0,msgT=0,hudT=0,cur=0,nH=1,mode='',amb,spot,pl,lampMat,lv=1,again=()=>{};
const inp={mx:0,mz:0,fire:0,run:0,jump:0,jp:0,jpT:0};
const gunM=new T.Mesh(new T.BoxGeometry(.12,.14,.6),mat(0x222222));gunM.position.set(.3,-.28,-.6);
let AC;const beep=(f,d,tp='square',v=.04)=>{try{AC=AC||new AudioContext();const o=AC.createOscillator(),g=AC.createGain();o.type=tp;o.frequency.value=f;g.gain.value=v;o.connect(g);g.connect(AC.destination);o.start();o.stop(AC.currentTime+d)}catch(e){}};
const say=t=>{$('msg').textContent=t;msgT=3},flash=()=>{const f=$('fl');f.style.opacity=.6;setTimeout(()=>f.style.opacity=0,150)};
const hOf=x=>Math.floor(x/W),bx=x=>{const h=houses.get(hOf(x));return h?h.boxes:EMPTY};

// ---------- ФИЗИКА ----------
const RAD=.3;
const blocked=(x,z,y,h)=>{for(const b of bx(x))if(x+RAD>b.x0&&x-RAD<b.x1&&z+RAD>b.z0&&z-RAD<b.z1&&y+h>b.y0&&y+.55<b.y1)return 1;return 0};
const ground=(x,z,y)=>{let g=-99;for(const b of bx(x))if(x>b.x0-.2&&x<b.x1+.2&&z>b.z0-.2&&z<b.z1+.2&&b.y1<=y+.6&&b.y1>g)g=b.y1;return g};
function phys(e,vx,vz,dt){const h=e.cr?1.1:1.8;const nx=e.x+vx*dt;if(!blocked(nx,e.z,e.y,h))e.x=nx;const nz=e.z+vz*dt;if(!blocked(e.x,nz,e.y,h))e.z=nz;
 e.vy-=24*dt;const ny=e.y+e.vy*dt,g=ground(e.x,e.z,e.y);if(ny<=g){e.y=g;e.vy=0;e.gr=1}else{e.y=ny;e.gr=0}}
function ray(o,d,R,sh){let x,y,z;for(let t=.3;t<=R;t+=.25){x=o.x+d.x*t;y=o.y+d.y*t;z=o.z+d.z*t;
 for(const b of bx(x))if(x>b.x0&&x<b.x1&&y>b.y0&&y<b.y1&&z>b.z0&&z<b.z1)return{x,y,z};
 for(const e of ents)if(e!==sh&&e.alive&&!e.hid){const dx=e.x-x,dz=e.z-z;if(dx*dx+dz*dz<.3&&y>e.y&&y<e.y+(e.isM?2.3:e.cr?1.2:1.9))return{x,y,z,e}}}return{x,y,z}}
function line(a,b,c){const g=new T.BufferGeometry().setFromPoints([new T.Vector3(a.x,a.y,a.z),new T.Vector3(b.x,b.y,b.z)]);const l=new T.Line(g,new T.LineBasicMaterial({color:c}));scene.add(l);fxs.push({m:l,t:.08})}
const angDir=(y,p)=>({x:-Math.sin(y)*Math.cos(p),y:Math.sin(p),z:-Math.cos(y)*Math.cos(p)});
function lclear(x1,z1,x2,z2,y,h=1.2){const d=Math.hypot(x2-x1,z2-z1),n=Math.ceil(d/.35);for(let i=0;i<=n;i++){const x=x1+(x2-x1)*i/n,z=z1+(z2-z1)*i/n;for(const b of bx(x))if(b.s&&x>b.x0&&x<b.x1&&z>b.z0&&z<b.z1&&y+h>b.y0&&y+h<b.y1)return 0}return 1}

// ---------- МОДЕЛИ ----------
const limb=(m,len,w,x,y,z)=>{const pv=new T.Group();pv.position.set(x,y,z);const l=new T.Mesh(new T.BoxGeometry(w,len,w),m);l.position.y=-len/2;pv.add(l);return pv};
const prt=(geo,m,x,y,z,sx=1,sy=1,sz=1)=>{const p=new T.Mesh(geo,m);p.position.set(x,y,z);p.scale.set(sx,sy,sz);return p};
function mk(o){const g=new T.Group(),sk=mat(0xe0b890),cl=mat(o.c||0x3355aa),pn=mat(o.p||0x2a2a3a),hr=mat(o.h||0x3a2a1a),bk=bas(0x000000);
 const lL=limb(pn,.82,.2,-.14,.85,0),lR=limb(pn,.82,.2,.14,.85,0),aL=limb(cl,.7,.14,-.34,1.46,0),aR=limb(cl,.7,.14,.34,1.46,0);
 g.add(lL,lR,aL,aR,prt(new T.BoxGeometry(.5,.66,.3),cl,0,1.17,0),prt(new T.SphereGeometry(.2,10,8),sk,0,1.66,0),prt(new T.SphereGeometry(.215,10,6,0,6.3,0,1.7),hr,0,1.69,0),
  prt(new T.SphereGeometry(.03,6,4),bk,-.07,1.68,-.18),prt(new T.SphereGeometry(.03,6,4),bk,.07,1.68,-.18));
 const xr=prt(new T.BoxGeometry(.9,1.9,.7),bas(0xff2222,{transparent:true,opacity:.0}),0,.95,0);g.add(xr);scene.add(g);
 return Object.assign({g,parts:{lL,lR,aL,aR},x:0,y:0,z:0,vy:0,yaw:0,alive:1,cd:0,cr:0,gr:0,lives:3,inv:0,hid:null,hidT:0,ph:0,mv:0,noise:0},o)}
function monsterModel(){const g=new T.Group(),sk=mat(0x8a8f96),dk=mat(0x14141c),bn=mat(0xd8d2c0),eye=bas(0xff2200),mt=bas(0x330000);
 const lL=limb(dk,1.1,.2,-.2,1.1,0),lR=limb(dk,1.1,.2,.2,1.1,0),aL=limb(sk,1.7,.13,-.5,1.95,0),aR=limb(sk,1.7,.13,.5,1.95,0);
 for(const a of[aL,aR]){for(let i=-1;i<=1;i++){const c=new T.Mesh(new T.ConeGeometry(.04,.4,5),bn);c.position.set(i*.05,-1.9,0);c.rotation.x=Math.PI;a.add(c)}}
 const head=new T.Group();head.position.set(0,2.15,-.1);head.add(prt(new T.SphereGeometry(.28,12,10),sk,0,0,0,.9,1.45,1),prt(new T.SphereGeometry(.07,8,6),eye,-.11,.08,-.24),prt(new T.SphereGeometry(.07,8,6),eye,.11,.08,-.24),
  prt(new T.BoxGeometry(.2,.16,.06),mt,0,-.22,-.22));for(let i=-2;i<=2;i++)head.add(prt(new T.ConeGeometry(.018,.1,4),bn,i*.04,-.3,-.23,1,1,1));
 g.add(lL,lR,aL,aR,head,prt(new T.CylinderGeometry(.3,.2,1.2,8),sk,0,1.55,.05,1,1,.7),prt(new T.CylinderGeometry(.22,.3,.5,8),dk,0,.95,.05));
 for(let i=0;i<5;i++){const s=new T.Mesh(new T.ConeGeometry(.07,.45,5),bn);s.position.set((i-2)*.1,1.8-Math.abs(i-2)*.2,.3);s.rotation.x=1.2;g.add(s)}
 g.userData={lL,lR,aL,aR,head};return g}

// ---------- ДОМ (бесконечная цепочка) ----------
const NL=[['ent',20,29,0],['hl',6,22.5,0],['hm',20,23,0],['hr',34,22.5,0],['A',3,27,0],['C',37.5,27,0],['dk',6.5,20,0],['dl',20.5,20,0],['dg',33.5,20,0],['k',7,10,0],['l',20,10,0],['g',33,10,0],['kl',14,10,0],['lg',27,10,0],['pW',1.5,23.5,0],['pE',38.5,23.5,0],
 ['uB',13.5,27,H],['u1',8,23,H],['ud1',16,23.5,H],['u2',22,24,H],['ud2',28,23.5,H],['u3',34,24,H],['upW',1.5,23.5,H],['upE',38.5,23.5,H],['ub1',4,20,H],['ub2',15,20,H],['ub3',25,20,H],['ub4',35,20,H],['ur1',5,10,H],['ur2',15,10,H],['ur3',25,10,H],['ur4',35,10,H],['ui1',10,10,H],['ui2',20,10,H],['ui3',30,10,H],
 ['bD',28,27,-H],['b1',33,22,-H],['b2',33,8,-H],['b3',26,22,-H],['b4',26,10,-H],['b5',20,22,-H],['b6',20,8,-H],['b7',14,22,-H],['b8',14,10,-H],['b9',7,22,-H],['b10',7,8,-H]];
const FUR=[['c',1.2,3,0],['t',7,12,0],['c',12.8,18,0],['t',20,6,0],['c',26,2,0],['b',35,4,0],['b',35,15,0],['c',38.8,10,0],['t',30,24,0],['c',1.2,28.4,0],['c',38.8,28.4,0],
 ['b',5,4,H],['c',1.2,13,H],['b',15,4,H],['c',12,18.5,H],['b',25,4,H],['t',25,14,H],['b',35,4,H],['c',38.8,16,H],['t',22,25,H],['c',14.8,29,H],['t',34,27,H],
 ['t',6,6,-H],['c',1.2,20,-H],['t',20,6,-H],['c',24.5,18,-H],['t',33,6,-H],['c',38.8,20,-H],['t',7,26,-H],['c',20,28.6,-H]];
const ISP=[[3,3,0],[37,3,0],[10,17,0],[30,17,0],[22,27,0],[6,24,0],[3,3,H],[17,3,H],[37,17,H],[22,27,H],[10,17,H],[3,28,H],[3,3,-H],[20,15,-H],[37,3,-H],[8,27,-H],[20,27,-H]];
const CRK=[[10,23,0],[30,23,0],[8,8,0],[32,8,0],[20,14,0],[10,23,H],[30,24,H],[5,12,H],[15,8,H],[25,12,H],[35,8,H],[20,14,-H]];
const LMP=[[7,10,0],[20,10,0],[33,10,0],[8,24,0],[20,24,0],[32,24,0],[5,10,H],[15,10,H],[25,10,H],[35,10,H],[8,24,H],[22,24,H],[34,24,H],[7,15,-H],[20,15,-H],[33,15,-H]];
function buildHouse(hi){const ox=hi*W,h={id:hi,boxes:[],vis:new Map(),grp:new T.Group(),nodes:[]};houses.set(hi,h);scene.add(h.grp);
 const V=(x0,y0,z0,x1,y1,z1,c)=>{let a=h.vis.get(c);if(!a)h.vis.set(c,a=[]);a.push([ox+(x0+x1)/2,(y0+y1)/2,(z0+z1)/2,x1-x0,y1-y0,z1-z0])};
 const B=(x0,y0,z0,x1,y1,z1,c,s=1)=>{h.boxes.push({x0:ox+x0,y0,z0,x1:ox+x1,y1,z1,s});V(x0,y0,z0,x1,y1,z1,c)};
 const seg=(lo,hi_,gaps,f)=>{let c=lo;for(const g of gaps.slice().sort((p,q)=>p[0]-q[0])){if(g[0]-c>.01)f(c,g[0]);c=g[1]}if(hi_-c>.01)f(c,hi_)};
 const wX=(z,xa,xb,y,gaps,c)=>seg(xa,xb,gaps,(a,b)=>B(a,y,z-.15,b,y+H,z+.15,c)),wZ=(x,za,zb,y,gaps,c)=>seg(za,zb,gaps,(a,b)=>B(x-.15,y,a,x+.15,y+H,b,c));
 const slab=(y0,y1,hx0,hz0,hx1,hz1,c)=>{B(0,y0,0,W,y1,hz0,c,0);B(0,y0,hz1,W,y1,D,c,0);B(0,y0,hz0,hx0,y1,hz1,c,0);B(hx1,y0,hz0,W,y1,hz1,c,0)};
 B(0,-H-.3,0,W,-H,D,0x2c2c30,0);slab(-.3,0,27.6,25.6,36.4,28.4,0x5a3e28);slab(H-.3,H,3.6,25.6,12,28.4,0x4a3a2e);B(0,2*H,0,W,2*H+.3,D,0x222226,0);
 const OC=0x6e5a48,IG=0xa39580,IU=0x8c98a8,IB=0x5b6068;
 for(const y of[-H,0,H]){const pas=y>=0?[[22,25]]:[];wX(0,0,W,y,[],OC);wX(D,0,W,y,[],OC);wZ(0,0,D,y,pas,OC);wZ(W,0,D,y,pas,OC)}
 wX(20,0,W,0,[[5,8],[19,22],[32,35]],IG);wZ(14,0,20,0,[[9,11]],IG);wZ(27,0,20,0,[[9,11]],IG);
 wX(20,0,W,H,[[3,5],[14,16],[24,26],[34,36]],IU);[10,20,30].forEach(x=>wZ(x,0,20,H,[[9,11]],IU));[16,28].forEach(x=>wZ(x,20,D,H,[[22,25]],IU));
 [14,26].forEach(x=>wZ(x,0,D,-H,[[9,11],[21,23]],IB));
 for(let i=0;i<8;i++)B(4+i,0,26,5+i,.425*(i+1),28,0x6e4b2a,0);for(let i=0;i<7;i++)B(35-i,-H,26,36-i,-.425*(i+1),28,0x5a4a3a,0);
 B(18,0,D-.4,22,2.7,D+.1,0x4a2410);V(21,1,D-.45,21.3,1.3,D-.35,0xd0b040);
 // ковры, картины, плинтус
 [[2,2,12,18,0x7a2a2a],[16,2,26,18,0x2a4a7a],[29,2,39,18,0x2a6a4a],[8,23,32,27.5,0x6a3a5a]].forEach(r=>V(r[0],.01,r[1],r[2],.04,r[3],r[4]));
 [[6,.16,0x2a5a8a],[16,.16,0xa04030],[24,.16,0x4a8a4a],[34,.16,0xb09030]].forEach(p=>{V(p[0],1.4,p[1],p[0]+2.2,2.5,p[1]+.1,p[2]);V(p[0],H+1.4,p[1],p[0]+2.2,H+2.5,p[1]+.1,p[2])});
 for(const y of[0,H,-H]){V(0,y,.15,W,y+.15,.25,0x2a2218);V(0,y,D-.25,W,y+.15,D-.15,0x2a2218)}
 // мебель
 FUR.forEach(([k,x,z,y])=>{h.fur=h.fur||[];const f={k,x:ox+x,z,y,h:hi};furn.push(f);
  if(k=='c'){B(x-.5,y,z-.35,x+.5,y+2.1,z+.35,0x5e3a1e);V(x-.03,y+.9,z-.37,x+.03,y+1.2,z-.34,0xd0b040)}
  else if(k=='t'){V(x-.75,y+.7,z-.45,x+.75,y+.78,z+.45,0x8a5a2a);for(const a of[-.65,.65])for(const b of[-.35,.35])V(x+a-.04,y,z+b-.04,x+a+.04,y+.7,z+b+.04,0x6a4220)}
  else{B(x-.55,y,z-1,x+.55,y+.45,z+1,0x7a3a4a,0);V(x-.55,y+.45,z+.55,x+.55,y+.52,z+.95,0xeeeeee);V(x-.57,y,z-1.05,x+.57,y+.9,z-.97,0x4a2a1a)}});
 // свет
 LMP.forEach(([x,z,y])=>{const m=new T.Mesh(new T.BoxGeometry(.6,.1,.6),lampMat);m.position.set(ox+x,y+H-.12,z);h.grp.add(m)});
 // узлы
 const nm={};NL.forEach(([n,x,z,y])=>{const o={x:ox+x,z,y,adj:[],h:hi};nm[n]=o;h.nodes.push(o)});h.nm=nm;
 h.nodes.forEach((a,i)=>{for(let j=i+1;j<h.nodes.length;j++){const b=h.nodes[j];if(Math.abs(a.y-b.y)<1&&Math.hypot(a.x-b.x,a.z-b.z)<16&&lclear(a.x,a.z,b.x,b.z,a.y)){a.adj.push(b);b.adj.push(a)}}});
 [['A','uB'],['C','bD']].forEach(([a,b])=>{nm[a].adj.push(nm[b]);nm[b].adj.push(nm[a])});
 // предметы и скрипы
 const sp=shuf(ISP);const cnt=hi==0?[['gun',1],['am',2],['med',2]]:[['gun',Math.random()<.4?1:0],['am',2],['med',Math.random()<.6?1:0]];let si=0;
 cnt.forEach(([k,n])=>{for(let i=0;i<n;i++){const p=sp[si++],m=new T.Mesh(new T.BoxGeometry(.5,.3,.5),bas(k=='gun'?0xaaaaaa:k=='am'?0xffcc00:0xff3344));m.position.set(ox+p[0],p[2]+.3,p[1]);h.grp.add(m);items.push({k,g:pick(['sg','pi']),x:ox+p[0],z:p[1],y:p[2],m,h:hi})}});
 shuf(CRK).slice(0,3).forEach(c=>creaks.push({x:ox+c[0],z:c[1],y:c[2],cd:0,h:hi}));
 // инстансы
 const d=new T.Object3D();h.vis.forEach((arr,c)=>{const im=new T.InstancedMesh(new T.BoxGeometry(1,1,1),mat(c),arr.length);im.frustumCulled=false;arr.forEach((a,i)=>{d.position.set(a[0],a[1],a[2]);d.scale.set(a[3],a[4],a[5]);d.updateMatrix();im.setMatrixAt(i,d.matrix)});h.grp.add(im)});h.vis=null;
 refreshNodes()}
function refreshNodes(){nodesAll=[...houses.values()].flatMap(h=>h.nodes);nodesAll.forEach(n=>n.adj=n.adj.filter(a=>houses.has(a.h)));
 for(const[id,h]of houses){const n=houses.get(id+1);if(n)for(const[a,b]of[['pE','pW'],['upE','upW']]){const x=h.nm[a],y=n.nm[b];if(!x.adj.includes(y)){x.adj.push(y);y.adj.push(x)}}}}
function removeHouse(id){const h=houses.get(id);scene.remove(h.grp);h.grp.traverse(o=>{if(o.geometry)o.geometry.dispose()});houses.delete(id);
 for(const arr of[furn,items,creaks]){for(let i=arr.length-1;i>=0;i--)if(arr[i].h===id)arr.splice(i,1)}
 for(const e of ents)if(!e.isP&&hOf(e.x)===id){e.hid=null;e.x=cur*W+20;e.z=24;e.y=0;e.path=null}refreshNodes()}
function ensure(c){cur=c;for(let h=c-1;h<=c+1;h++)if(!houses.has(h))buildHouse(h);for(const id of[...houses.keys()])if(Math.abs(id-c)>1)removeHouse(id)}

// ---------- НАВИГАЦИЯ ----------
function near(p){let bi=null,bd=1e9,fb=null,fd=1e9;for(const n of nodesAll){if(Math.abs(n.y-p.y)>2||Math.abs(n.x-p.x)>30)continue;const d=Math.hypot(n.x-p.x,n.z-p.z);if(d<fd){fd=d;fb=n}if(d<bd&&d<22&&lclear(p.x,p.z,n.x,n.z,p.y)){bd=d;bi=n}}return bi||fb}
function route(e,d){const a=near(e),b=near(d),fin={x:d.x,y:d.y,z:d.z};if(!a||!b)return[fin];for(const n of nodesAll){n.d=1e9;n.pv=null;n.dn=0}a.d=0;
 for(;;){let u=null;for(const n of nodesAll)if(!n.dn&&(!u||n.d<u.d))u=n;if(!u||u.d>=1e9)break;u.dn=1;if(u===b)break;for(const v of u.adj){const w=u.d+Math.hypot(u.x-v.x,u.z-v.z)+Math.abs(u.y-v.y)*3;if(w<v.d){v.d=w;v.pv=u}}}
 const r=[];for(let c=b;c;c=c.pv)r.unshift({x:c.x,y:c.y,z:c.z});r.push(fin);while(r.length>1&&Math.abs(r[0].y-e.y)<1&&Math.abs(r[1].y-e.y)<1.2&&lclear(e.x,e.z,r[1].x,r[1].z,e.y))r.shift();return r}
function navStep(e,d,sp,dt){e.pt=(e.pt||0)-dt;if(!e.path||e.pt<=0||!e.pd||Math.hypot(e.pd.x-d.x,e.pd.z-d.z)>1.5||Math.abs(e.pd.y-d.y)>1.5){e.path=route(e,d);e.pd={x:d.x,y:d.y,z:d.z};e.pt=4}
 const p=e.path[0];if(!p)return 1;const dx=p.x-e.x,dz=p.z-e.z,dd=Math.hypot(dx,dz),st=sp*dt;e.mv=1;
 if(dd<=st+.05){e.x=p.x;e.z=p.z;e.y=p.y;e.path.shift()}else{e.x+=dx/dd*st;e.z+=dz/dd*st;e.y+=(p.y-e.y)*st/dd;e.yaw=Math.atan2(-dx,-dz)}return e.path.length==0}
const sight=(a,b)=>Math.abs(a.y-b.y)<=2&&lclear(a.x,a.z,b.x,b.z,Math.min(a.y,b.y),b.cr?.9:1.5);

// ---------- ИГРОВАЯ ЛОГИКА ----------
function hide(e,f){if(f.used&&f.used!==e)return;if(f.k!='c'&&e.isP&&!e.cr){say('Присядьте, чтобы залезть под '+(f.k=='b'?'кровать':'стол'));return}e.px=e.x;e.pz=e.z;e.py=e.y;e.hid=f;f.used=e;e.hidT=0;e.x=f.x;e.z=f.z;e.y=f.y}
function unhide(e){if(!e.hid)return;e.hid.used=null;e.hid=null;e.x=e.px;e.z=e.pz;e.y=e.py}
function use(){if(P.hid){unhide(P);return}let b=null,bd=1.9;for(const f of furn)if(Math.abs(f.y-P.y)<2){const d=Math.hypot(f.x-P.x,f.z-P.z);if(d<bd){bd=d;b=f}}if(b)hide(P,b);else say('Рядом нет укрытия')}
function shootH(){if(P.cd>0||!P.gun||P.hid)return;if(P.am<=0){say('Нет патронов');P.cd=.6;return}P.am--;const sg=P.gun=='sg';P.cd=sg?1.1:.5;const o={x:P.x,y:P.y+1.55,z:P.z};beep(sg?90:170,.15,'sawtooth',.08);gunM.position.z=-.45;evs.push({x:P.x,y:P.y,z:P.z,r:25,t:5});
 const hs=new Set();for(let i=0;i<(sg?5:1);i++){const d=angDir(yaw+(sg?RN(-.06,.06):0),pitch+(sg?RN(-.05,.05):0)),r=ray(o,d,sg?14:40,P);line({x:o.x,y:o.y-.15,z:o.z},r,0xffee66);if(r.e)hs.add(r.e)}
 hs.forEach(e=>{if(e.isM)dmgM(sg?1:.2,.6);else{if(e.hid)unhide(e);e.alive=0;e.g.visible=false;say(e.name+' убит')}})}
function dmgM(d,st){M.hp-=d;M.stun=st;if(M.hp<=0){M.state='wait';M.t=30;M.alive=0;M.g.visible=false;say('Монстр убит! Но он вернётся…')}}
function stab(){if(P.cd>0||P.hid)return;P.cd=.55;ksw=1;beep(300,.05,'triangle',.04);const r=ray({x:P.x,y:P.y+1.5,z:P.z},angDir(yaw,pitch),2.4,P);if(r.e&&r.e.isM){dmgM(.25,.5);beep(120,.1,'sawtooth',.08)}}
function mHit(e){e.inv=2;e.lives--;M.stun=1.3;if(e.isP){flash();beep(70,.3,'sawtooth',.1);if(e.hid)unhide(e);if(e.lives<=0){e.alive=0;over=1;$('end').innerHTML='<h2>💀 Вы погибли<br>Волн пережито: '+Math.max(0,waves-1)+'</h2>';endBtns()}else say('Монстр ударил! Жизней: '+e.lives)}
 else if(e.lives<=0){e.alive=0;e.g.visible=false;if(e.hid){e.hid.used=null;e.hid=null}say(e.name+' погиб')}}
function mAI(dt){if(M.stun>0){M.stun-=dt;return}let tg=null,best=1e9,md='patrol';
 for(const e of ents){if(e.isM||!e.alive)continue;const d=Math.hypot(e.x-M.x,e.z-M.z);if(Math.abs(e.y-M.y)>2.5)continue;
  const seen=d<14&&sight(M,e)&&(!e.hid||(e.hid.k!='c'&&d<1.8)),heard=!e.hid&&d<e.noise;if((seen||heard)&&d<best){best=d;tg=e;md=seen?'chase':'hear'}}
 if(!tg)for(const v of evs)if(Math.abs(v.y-M.y)<2.5&&Math.hypot(v.x-M.x,v.z-M.z)<v.r){tg={x:v.x,y:v.y,z:v.z};md='hear';break}
 if(tg){M.dest={x:tg.x,y:tg.y,z:tg.z};M.lk={x:tg.x,y:tg.y,z:tg.z};M.srch=0}
 else if(M.lk){md='hear';M.dest=M.lk;
  if(Math.hypot(M.lk.x-M.x,M.lk.z-M.z)<1.6&&Math.abs(M.lk.y-M.y)<2){M.srch=(M.srch||0)+1;M.path=null;
   if(M.srch>4)M.lk=null;else{const ns=nodesAll.filter(n=>Math.hypot(n.x-M.lk.x,n.z-M.lk.z)<22&&Math.abs(n.y-M.lk.y)<2.5);if(ns.length){const n=pick(ns);M.lk={x:n.x,y:n.y,z:n.z};M.dest=M.lk}else M.lk=null}}}
 if(!tg&&!M.lk&&(!M.dest||(M.path&&M.path.length==0&&Math.hypot(M.dest.x-M.x,M.dest.z-M.z)<1.6))){
  const ns=nodesAll.filter(n=>Math.abs(hOf(n.x)-cur)<=1),fl=ns.filter(n=>Math.abs(n.y-P.y)<2&&Math.abs(hOf(n.x)-cur)<1),n=pick(Math.random()<.6&&fl.length?fl:ns);M.dest={x:n.x,y:n.y,z:n.z}}
 navStep(M,M.dest,md=='chase'?5.2:md=='hear'?3.6:2.4,dt);
 for(const e of ents){if(e.isM||!e.alive||e.inv>0)continue;const d=Math.hypot(e.x-M.x,e.z-M.z);if(d<1.2&&Math.abs(e.y-M.y)<2&&!(e.hid&&(e.hid.k=='c'||d>1.8)))mHit(e)}}
function botH(b,dt){b.cr=1;b.mv=0;
 if(b.hid){b.hidT+=dt;if(b.hidT>(b.hid.k=='c'?20:999)||(M.state=='wait'&&M.t>12&&b.hidT>3)){b.last=b.hid;unhide(b);b.last=b.last}return}
 if(M.state=='on'||M.t<8){if(!b.spot||(b.spot.used&&b.spot.used!==b)||!furn.includes(b.spot)){let bd=1e9;b.spot=null;for(const f of furn)if(!f.used&&f!==b.last){const d=Math.hypot(f.x-b.x,f.z-b.z)+Math.abs(f.y-b.y)*5;if(d<bd){bd=d;b.spot=f}}}
  if(b.spot){navStep(b,b.spot,3.2,dt);if(Math.hypot(b.spot.x-b.x,b.spot.z-b.z)<.7&&Math.abs(b.spot.y-b.y)<1){hide(b,b.spot);b.spot=null}}}
 else{b.spot=null;if(!b.dest||navStep(b,b.dest,2,dt)){const ns=nodesAll.filter(n=>Math.abs(hOf(n.x)-cur)<=1),n=pick(ns);b.dest={x:n.x,y:n.y,z:n.z}}}}
function ctl(dt){const e=P,f=inp.mz,r=inp.mx;e.mv=Math.hypot(f,r)>.15&&!e.hid;e.yaw=yaw;if(e.hid)return;
 const was=e.gr;if(e.gr)e.gt=(e.gt||0)+dt;inp.jpT-=dt;if(inp.jpT<=0)inp.jp=0;
 if(e.gr&&(inp.jp||(cfg.auto&&inp.jump))){e.bh=e.gt<.18?(e.bh||0)+1:0;e.gt=0;e.vy=7;e.gr=0;inp.jp=0}else if(e.gr&&e.gt>.18)e.bh=0;
 const sp=(e.cr?1.7:inp.run?6.2:3.6)*(1+Math.min(e.bh||0,8)*.09);e.run=inp.run&&!e.cr;
 phys(e,(-Math.sin(yaw)*f+Math.cos(yaw)*r)*sp,(-Math.cos(yaw)*f-Math.sin(yaw)*r)*sp,dt);
 if(!was&&e.gr&&(e.bh||0)>0)evs.push({x:e.x,y:e.y,z:e.z,r:10,t:3});
 if(inp.fire){if(P.gun)shootH();else stab()}}
function hUpdate(dt){M.mv=0;M.t-=dt;
 if(M.state=='wait'&&M.t<=0){M.state='on';M.t=30;M.alive=1;M.hp=4;M.g.visible=true;M.x=cur*W+20;M.z=29;M.y=0;M.path=null;M.dest=null;M.stun=1;waves++;say('Свет погас — монстр вошёл в дом!');beep(60,.5,'sawtooth',.1)}
 else if(M.state=='on'&&M.t<=0){M.state='wait';M.t=30;M.alive=0;M.g.visible=false;say('Монстр ушёл… включился свет')}
 for(let i=evs.length-1;i>=0;i--){evs[i].t-=dt;if(evs[i].t<=0)evs.splice(i,1)}for(const c of creaks)c.cd-=dt;
 for(const e of ents){if(e.isM||!e.alive)continue;e.inv-=dt;e.cd-=dt;if(e.isP)ctl(dt);else botH(e,dt);
  e.noise=e.hid?0:(e.bh>0&&!e.gr)?14:!e.mv?0:e.cr?0:e.run?14:7;if(e.isP&&e.hid){e.hidT+=dt;if(e.hid.k=='c'&&e.hidT>20){unhide(e);say('Время в шкафу вышло!')}}
  if(!e.cr&&e.mv&&!e.hid)for(const c of creaks)if(c.cd<=0&&Math.abs(c.y-e.y)<1.5&&Math.hypot(c.x-e.x,c.z-e.z)<.9){c.cd=4;evs.push({x:c.x,y:c.y,z:c.z,r:22,t:6});beep(200,.25,'sawtooth',.06);if(e.isP)say('Скрип половицы!')}
  if(e.isP)for(const it of items)if(!it.got&&Math.abs(it.y-e.y)<1.5&&Math.hypot(it.x-e.x,it.z-e.z)<1.1){it.got=1;it.m.visible=false;
   if(it.k=='gun'){e.gun=it.g;e.am+=4;say(it.g=='sg'?'Найден дробовик!':'Найден пистолет!')}else if(it.k=='am'){e.am+=4;say('Патроны +4')}else{e.lives=Math.min(3,e.lives+1);say('Аптечка! Жизней: '+e.lives)}}}
 if(M.alive)mAI(dt);gunM.visible=!!P.gun&&!P.hid;if(kvm)kvm.visible=!P.gun&&!P.hid;ensure(hOf(P.x))}
function startHorror(n){mode='h';inp.fire=0;nH=n;scene=new T.Scene();houses=new Map();ents=[];fxs=[];items=[];furn=[];creaks=[];evs=[];nodesAll=[];over=0;waves=0;cur=0;lv=1;cam.clear();scene.add(cam);cam.add(gunM);kvm=makeKnife(cfg.k.t,cfg.k.s);kvm.scale.setScalar(1.3);cam.add(kvm);
 hideAll();showCtl(1);lay();
 lampMat=bas(0xffe9a8);scene.fog=new T.Fog(0x201a14,8,64);scene.background=new T.Color(0x201a14);amb=new T.AmbientLight(0xffe8c8,1.7);scene.add(amb);
 spot=new T.SpotLight(0xffffff,1,30,.7,.5);spot.position.set(0,0,0);spot.target.position.set(0,0,-5);cam.add(spot,spot.target);pl=new T.PointLight(0xff2200,0,10);scene.add(pl);
 P=mk({isP:1,c:0x2255cc,name:'Вы'});P.g.visible=false;P.x=20;P.z=26;P.y=0;P.am=0;P.gun=null;yaw=0;pitch=0;ents.push(P);
 for(let i=1;i<n;i++){const b=mk({isB:1,c:[0xcc3333,0x33aa33,0xccaa22][i-1],h:[0x111111,0xaa6622,0xdddd88][i-1],name:'Бот '+i});b.x=[17,23,20][i-1];b.z=[27,27,24][i-1];ents.push(b)}
 const g=monsterModel();g.visible=false;scene.add(g);M={g,isM:1,alive:0,state:'wait',t:30,hp:4,x:20,y:0,z:29,vy:0,yaw:0,cr:0,stun:0,hid:null,mv:0,ph:0,parts:g.userData};ents.push(M);
 ensure(0);gunM.visible=false;again=()=>startHorror(n);say('Свет горит — монстр придёт через 30 с. E — спрятаться, «Сесть» — тише.');hud()}
function act(a){if(!P||over)return;if(a=='use')use();if(a=='insp'){if(P.gun)say('Нож убран, пока в руках оружие');else if(kinsT<=0)kinsT=2.4}
 if(a=='crouch'){P.cr=P.cr?0:1;$('b_crouch').style.background=P.cr?'#2b6':''}if(a=='run'){inp.run=inp.run?0:1;$('b_run').style.background=inp.run?'#2b6':''}}
function hud(){if(!P)return;$('hud').innerHTML=`${'❤'.repeat(Math.max(0,P.lives))} &nbsp; ${P.gun?(P.gun=='sg'?'Дробовик':'Пистолет')+' · патроны '+P.am:'Кулаки'+(P.am?' (патроны '+P.am+')':'')} &nbsp; 🏠 ${cur}<br>${M.state=='on'?'👹 Монстр в доме: '+Math.ceil(M.t)+'с':'💡 Свет горит · монстр через '+Math.ceil(M.t)+'с'} · волна ${waves}`+(P.hid?`<br>Спрятаны · E — выйти${P.hid.k=='c'?' ('+Math.max(0,Math.ceil(20-P.hidT))+'с)':''}`:'')+(nH>1?'<br>'+ents.filter(e=>e.isB).map(e=>e.name+(e.alive?' '+'❤'.repeat(e.lives):' ✖')).join(' · '):'')}
function endBtns(){const el=$('end');[['Ещё раз',()=>again()],['В меню',openMenu]].forEach(([t,f])=>{const b=document.createElement('button');b.textContent=t;b.onclick=f;el.appendChild(b)});el.classList.remove('h')}
function lights(dt){let L=M.state=='wait'?1:0;if(M.state=='wait'&&M.t<2.5){L=Math.random()<.5?1:0;lv=L}else lv+=(L-lv)*Math.min(1,dt*4);
 amb.intensity=.2+lv*1.5;scene.fog.near=2+lv*6;scene.fog.far=24+lv*42;const c=.13*lv;scene.fog.color.setRGB(c*1.2,c,c*.7);scene.background.copy(scene.fog.color);
 lampMat.color.setRGB(.12+.88*lv,.12+.8*lv,.1+.55*lv);spot.intensity=3.2*(1-.75*lv);pl.intensity=M.alive?1.6:0;pl.position.set(M.x,M.y+1.8,M.z)}
function anim(e,dt){const p=e.parts;if(!p)return;e.ph+=e.mv?dt*(e.isM?7:9):0;const s=e.mv?Math.sin(e.ph)*.7:0;p.lL.rotation.x=s;p.lR.rotation.x=-s;p.aL.rotation.x=-s*.8-(e.isM?.4:0);p.aR.rotation.x=s*.8-(e.isM?.4:0);
 if(e.isM){const hd=p.head;hd.rotation.z=Math.sin(performance.now()/300)*.15;hd.rotation.x=.2}}
function sync(dt){for(const e of ents){e.g.position.set(e.x,e.y,e.z);e.g.rotation.y=e.yaw;if(!e.isM)e.g.visible=!!e.alive&&!e.isP&&!e.hid;anim(e,dt)}}
let last=performance.now();
function loop(t){requestAnimationFrame(loop);const dt=Math.min(.05,(t-last)/1000);last=t;if(mode=='k'){kLoop(dt);return}if(mode!='h')return;
 if(!over){hUpdate(dt);for(let i=fxs.length-1;i>=0;i--){fxs[i].t-=dt;if(fxs[i].t<=0){scene.remove(fxs[i].m);fxs.splice(i,1)}}}
 if(msgT>0){msgT-=dt;if(msgT<=0)$('msg').textContent=''}gunM.position.z+=(-.6-gunM.position.z)*Math.min(1,dt*12);kvmUpdate(dt);
 lights(dt);sync(dt);hudT-=dt;if(hudT<=0){hudT=.12;hud()}
 const eye=P.hid?(P.hid.k=='c'?1.6:.45):(P.cr?1:1.6);cam.position.set(P.x,P.y+eye,P.z);cam.rotation.set(pitch,yaw,0,'YXZ');ren.render(scene,cam)}
requestAnimationFrame(loop);

// ---------- НАСТРОЙКИ ----------
const CTL=[['js','Джойстик',150,.12,.75],['b_fire','Огонь / удар ножом',92,.9125,.71],['b_jump','Прыжок / банихоп',64,.8,.86],['b_crouch','Сесть',64,.93,.48],['b_run','Бег',64,.29,.86],['b_use','E — спрятаться',64,.8,.66],['b_insp','Осмотр ножа',64,.62,.86],['b_menu','Меню',46,.05,.1]];
let cfg={g:1,sens:1,auto:0,k:{t:0,s:0},el:{}};try{Object.assign(cfg,JSON.parse(localStorage.getItem('cfg')||'{}'))}catch(e){}
const save=()=>{try{localStorage.setItem('cfg',JSON.stringify(cfg))}catch(e){}};
const hideAll=()=>['menu','end','set','kmenu'].forEach(i=>$(i).classList.add('h')),showCtl=v=>{$('ui').style.display=v?'block':'none';$('js').style.display=v?'block':'none'};
function lay(){for(const[id,n,sz,dx,dy]of CTL){const el=$(id),c=cfg.el[id]||{},s=c.s||1,px=sz*s*cfg.g;el.style.left=(c.x??dx)*innerWidth+'px';el.style.top=(c.y??dy)*innerHeight+'px';el.style.width=el.style.height=px+'px';el.style.fontSize=Math.max(10,px*.28)+'px';
 if(id=='js'){const k=$('kn').style;k.left=k.top=px*.335+'px';k.width=k.height=px*.33+'px'}}}
addEventListener('resize',lay);
let edit=0,selId=null,dragId=null;
function select(id){selId=id;CTL.forEach(c=>$(c[0]).style.outline=c[0]==id?'3px solid #ff0':'');$('edname').textContent=CTL.find(a=>a[0]==id)[1];$('edsz').value=((cfg.el[id]||{}).s||1)*100}
function edL(id){$(id).addEventListener('pointerdown',e=>{if(!edit)return;e.preventDefault();e.stopImmediatePropagation();select(id);dragId=id;try{$(id).setPointerCapture(e.pointerId)}catch(_){}})}
addEventListener('pointermove',e=>{if(!edit||!dragId)return;const c=cfg.el[dragId]=cfg.el[dragId]||{};c.x=Math.min(.98,Math.max(.02,e.clientX/innerWidth));c.y=Math.min(.98,Math.max(.02,e.clientY/innerHeight));lay()});
addEventListener('pointerup',()=>{if(dragId){dragId=null;save()}});
function startEdit(){edit=1;hideAll();showCtl(1);$('ed').classList.remove('h');lay();select('b_fire')}
function endEdit(){edit=0;dragId=null;CTL.forEach(c=>$(c[0]).style.outline='');$('ed').classList.add('h');save();showCtl(0);openSet()}
$('edsz').oninput=()=>{(cfg.el[selId]=cfg.el[selId]||{}).s=$('edsz').value/100;lay()};$('edsz').onchange=save;
$('edok').onclick=endEdit;$('edrst').onclick=()=>{delete cfg.el[selId];save();lay();select(selId)};
function openSet(){hideAll();showCtl(0);mode='';const el=$('set');el.innerHTML='<h2>⚙ Настройки</h2>';
 const sl=(t,min,max,v,f)=>{const l=document.createElement('label'),b=document.createElement('b'),i=document.createElement('input');l.style.cssText='display:block;text-align:center';i.type='range';i.min=min;i.max=max;i.value=v;i.style.cssText='width:260px;display:block;margin:4px auto';
  const u=()=>b.textContent=t+': '+i.value+'%';u();i.oninput=()=>{f(i.value/100);u();lay()};i.onchange=save;l.append(b,i);el.appendChild(l)};
 const bt=(t,f)=>{const b=document.createElement('button');b.textContent=t;b.onclick=f;el.appendChild(b);return b};
 sl('Размер всех кнопок',50,160,Math.round(cfg.g*100),v=>cfg.g=v);sl('Чувствительность камеры',40,250,Math.round(cfg.sens*100),v=>cfg.sens=v);
 const ab=bt('',()=>{cfg.auto=cfg.auto?0:1;lab();save()}),lab=()=>ab.textContent='Авто-банихоп (держать прыжок): '+(cfg.auto?'ВКЛ':'ВЫКЛ');lab();
 bt('🎛 Расположение и размер кнопок',startEdit);bt('Сбросить все кнопки',()=>{cfg.el={};cfg.g=1;save();openSet()});bt('← Назад',openMenu);el.classList.remove('h')}

// ---------- НОЖИ ----------
const KT=['Боевой','Керамбит','Танто','Стилет'];
const KS=[{n:'Сталь',c:0xc9ced6,e:0,ei:0,h:0x2a2a2e},{n:'Золото',c:0xe0b83a,e:0x3a2800,ei:.5,h:0x4a2f10},{n:'Кровавый',c:0x9a1218,e:0x550000,ei:.5,h:0x1a0a0a},{n:'Неон',c:0x00e5ff,e:0x00c8ff,ei:.9,h:0x101828},
 {n:'Лёд',c:0xa8e4ff,e:0x2a70b0,ei:.4,h:0x203848},{n:'Огонь',c:0xff5a10,e:0xff3000,ei:.8,h:0x2a0a00,a:'fire'},{n:'Ночь',c:0x1a1626,e:0x7a3aff,ei:.5,h:0x0a0a10},{n:'Радуга',c:0xffffff,e:0xffffff,ei:.5,h:0x181820,a:'rain'}];
function blade(t){const s=new T.Shape();
 if(t==0){s.moveTo(-.03,0);s.lineTo(-.03,.26);s.lineTo(0,.37);s.lineTo(.04,.25);s.lineTo(.035,0)}
 else if(t==1){s.moveTo(-.02,0);s.quadraticCurveTo(-.17,.17,-.05,.39);s.quadraticCurveTo(.02,.2,.035,0)}
 else if(t==2){s.moveTo(-.03,0);s.lineTo(-.03,.3);s.lineTo(.036,.39);s.lineTo(.036,0)}
 else{s.moveTo(-.022,0);s.lineTo(-.01,.43);s.lineTo(.01,.43);s.lineTo(.022,0)}
 s.closePath();const g=new T.ExtrudeGeometry(s,{depth:.012,bevelEnabled:false});g.translate(0,0,-.006);return g}
function makeKnife(t,si){const sk=KS[si]||KS[0],g=new T.Group(),bm=new T.MeshStandardMaterial({color:sk.c,metalness:.6,roughness:.3,emissive:sk.e,emissiveIntensity:sk.ei}),hm=new T.MeshStandardMaterial({color:sk.h,metalness:.2,roughness:.6}),hl=t==1?.14:.22;
 const bl=new T.Mesh(blade(t),bm);bl.position.y=.01;g.add(bl);const h=new T.Mesh(new T.CylinderGeometry(.026,.03,hl,8),hm);h.position.y=-hl/2;g.add(h);g.add(prt(new T.BoxGeometry(t==3?.12:.09,.02,.045),bm,0,.01,0));
 if(t==1){const r=new T.Mesh(new T.TorusGeometry(.045,.01,6,12),bm);r.position.y=-hl-.03;g.add(r)}else g.add(prt(new T.SphereGeometry(.032,8,6),bm,0,-hl-.01,0));
 g.userData={bm,sk};return g}
function skinAnim(g,t){const u=g.userData,a=u.sk.a;if(a=='fire')u.bm.emissiveIntensity=.7+.5*Math.sin(t*9);else if(a=='rain'){u.bm.color.setHSL((t*.3)%1,.9,.55);u.bm.emissive.setHSL((t*.3+.1)%1,.9,.5)}}
let kvm=null,ksw=0,kinsT=0;
function kvmUpdate(dt){if(!kvm)return;ksw=Math.max(0,ksw-dt*3);kinsT=Math.max(0,kinsT-dt);skinAnim(kvm,performance.now()/1000);
 let px=.3,py=-.3,pz=-.52,rx=-1.15,ry=.25,rz=-.15;
 if(kinsT>0){const p=1-kinsT/2.4,e=Math.sin(p*Math.PI);px-=px*e;py+=(-.1-py)*e;pz+=(-.42-pz)*e;rx-=.7*e;ry=p*Math.PI*3;rz=Math.sin(p*Math.PI*2)*.9}
 if(ksw>0){const s=Math.sin((1-ksw)*Math.PI);pz-=.22*s;rx+=.7*s;px-=.1*s}
 kvm.position.set(px,py,pz);kvm.rotation.set(rx,ry,rz)}
let ksc,kc,kp,kpk,kt=0,ksn=0,kdrag=0,kry=0,krx=.2,kins=0;
function kInit(){if(ksc)return;ksc=new T.Scene();ksc.background=new T.Color(0x0c0c16);ksc.add(new T.AmbientLight(0xffffff,.9));const dl=new T.DirectionalLight(0xffffff,2.2);dl.position.set(3,5,4);ksc.add(dl);const p1=new T.PointLight(0x6a88ff,2,10);p1.position.set(-3,1,2);ksc.add(p1);
 const fl=new T.Mesh(new T.CylinderGeometry(1.3,1.3,.05,32),mat(0x1a1a28));fl.position.y=-1.05;ksc.add(fl);kc=new T.PerspectiveCamera(40,innerWidth/innerHeight,.1,20);kc.position.set(0,0,2.6);kp=new T.Group();ksc.add(kp)}
function kRefresh(){kInit();kp.clear();kpk=makeKnife(kt,ksn);kpk.position.y=-.1;kpk.scale.setScalar(2);kp.add(kpk)}
function kLoop(dt){if(!ksc)return;if(!kdrag)kry+=dt*.5;let ex=0;if(kins>0){kins=Math.max(0,kins-dt);const p=1-kins/2.4;ex=p*Math.PI*4;kp.position.y=Math.sin(p*Math.PI)*.15}else kp.position.y=0;
 kp.rotation.set(krx,kry+ex,.45);skinAnim(kpk,performance.now()/1000);kc.aspect=innerWidth/innerHeight;kc.updateProjectionMatrix();ren.render(ksc,kc)}
function kui(){const el=$('kmenu');el.innerHTML='';const top=document.createElement('div'),bot=document.createElement('div');el.append(top,bot);
 const row=p=>{const d=document.createElement('div');d.className='row';p.appendChild(d);return d},add=(r,t,f,css)=>{const b=document.createElement('button');b.className='sm';b.textContent=t;b.onclick=f;if(css)b.style.cssText=css;r.appendChild(b)};
 const r1=row(top);KT.forEach((n,i)=>add(r1,n,()=>{kt=i;kRefresh();kui()},i==kt?'background:#c82':''));
 const r0=row(top);r0.style.marginTop='6px';add(r0,'🔍 Осмотреть',()=>{kins=2.4});const cur_=cfg.k.t==kt&&cfg.k.s==ksn;add(r0,cur_?'✔ Выбрано':'Выбрать',()=>{cfg.k={t:kt,s:ksn};save();kui()},cur_?'background:#555':'');add(r0,'← Назад',openMenu);
 const r2=row(bot);KS.forEach((s,i)=>add(r2,s.n,()=>{ksn=i;kRefresh();kui()},`border-left:14px solid #${s.c.toString(16).padStart(6,'0')};`+(i==ksn?'background:#c82':'')));el.classList.remove('h')}
function openKnives(){hideAll();showCtl(0);mode='k';kt=cfg.k.t;ksn=cfg.k.s;kRefresh();kui()}

// ---------- ИНТЕРФЕЙС ----------
function openMenu(){mode='';P=null;hideAll();showCtl(0);$('hud').innerHTML='';$('msg').textContent='';const el=$('menu');el.innerHTML='<h2>👻 Хоррор: бесконечный дом<br><small>Сколько игроков?</small></h2>';
 [['Один',1],['Вдвоём (с ботом)',2],['Втроём',3],['Вчетвером',4]].forEach(([t,n])=>{const b=document.createElement('button');b.textContent=t;b.onclick=()=>startHorror(n);el.appendChild(b)});
 [['🔪 Ножи и скины',openKnives],['⚙ Настройки',openSet]].forEach(([t,f])=>{const b=document.createElement('button');b.textContent=t;b.style.background='#46c';b.onclick=f;el.appendChild(b)});el.classList.remove('h')}
function btn(id,txt,dn,up){const b=document.createElement('div');b.className='b';b.id=id;b.textContent=txt;$('ui').appendChild(b);edL(id);b.addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation();dn&&dn()});if(up)['pointerup','pointercancel','pointerleave'].forEach(n=>b.addEventListener(n,up))}
btn('b_fire','🔥',()=>inp.fire=1,()=>inp.fire=0);
btn('b_jump','⤒',()=>{inp.jump=1;inp.jp=1;inp.jpT=.25},()=>inp.jump=0);
btn('b_crouch','Сесть',()=>act('crouch'));btn('b_run','Бег',()=>act('run'));btn('b_use','E',()=>act('use'));btn('b_insp','🔍',()=>act('insp'));btn('b_menu','☰',openMenu);
const js=$('js'),kn=$('kn');let jid=null;edL('js');
function jm(e){const r=js.getBoundingClientRect(),R=r.width*.36;let dx=(e.clientX-r.left-r.width/2)/R,dy=(e.clientY-r.top-r.height/2)/R;const l=Math.hypot(dx,dy);if(l>1){dx/=l;dy/=l}inp.mx=dx;inp.mz=-dy;kn.style.transform=`translate(${dx*r.width*.3}px,${dy*r.width*.3}px)`}
js.addEventListener('pointerdown',e=>{e.preventDefault();jid=e.pointerId;js.setPointerCapture(jid);jm(e)});js.addEventListener('pointermove',e=>{if(e.pointerId===jid)jm(e)});
const je=e=>{if(e.pointerId===jid){jid=null;inp.mx=inp.mz=0;kn.style.transform=''}};js.addEventListener('pointerup',je);js.addEventListener('pointercancel',je);
const lk=$('lk');let lid=null,lx=0,ly=0;
lk.addEventListener('pointerdown',e=>{if(edit)return;if(lid===null){lid=e.pointerId;lx=e.clientX;ly=e.clientY;lk.setPointerCapture(lid)}});
lk.addEventListener('pointermove',e=>{if(e.pointerId!==lid)return;const dx=e.clientX-lx,dy=e.clientY-ly;lx=e.clientX;ly=e.clientY;
 if(mode=='k'){kry+=dx*.01;krx=Math.max(-1,Math.min(1,krx+dy*.01));kdrag=1}else{yaw-=dx*.006*cfg.sens;pitch=Math.max(-1.4,Math.min(1.4,pitch-dy*.006*cfg.sens))}});
['pointerup','pointercancel'].forEach(n=>lk.addEventListener(n,e=>{if(e.pointerId===lid){lid=null;kdrag=0}}));
lay();openMenu();
